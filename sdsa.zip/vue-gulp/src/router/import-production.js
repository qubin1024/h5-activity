module.exports = file => () => import('@/' + file + '.vue');
