import Vue from 'vue';
import Router from 'vue-router';
import store from '@/store';
import { isLogin, checkMenu } from '@/utils';
import kfsRouter from '@/systems/KFS/router/index';
//import vatRouter from '@/systems/Taxation/router/index';
import mgrIndexRounter from '@/systems/dataLoad/router/index';

// 开发环境不使用懒加载, 因为懒加载页面太多的话会造成webpack热更新太慢, 所以只有部署环境使用懒加载
const _import = require('./import-' + process.env.NODE_ENV);
console.log(process.env.NODE_ENV)
Vue.use(Router);
const router = new Router({
  // mode: 'history',
  routes: [
    {
      path: '/404',
      component: _import('views/error/404'),
      name: '404',
      desc: '404未找到',
      meta: { noCheckSession: true }
    },
    {
      path: '/kfs',
      component: _import('systems/KFS/index'),
      name: 'kfs',
      desc: 'kfsSys',
      children: kfsRouter
    },
    {
      path: '/system',
      component: _import('systems/dataLoad/index'),
      name: 'system',
      desc: 'mgrIndex'
      // children: mgrIndexRounter
    },
    {
      path: '/module/:id',
      component: _import('systems/modelmgr/index'),
      name: 'module',
      desc: 'modelmgr'
    },
    {
      path: '/login',
      component: _import('views/login/index'),
      name: 'deaultLogin',
      desc: 'deaultLogin',
      meta: { noCheckSession: true }
    },
    {
      path: '/',
      redirect: { name: 'deaultLogin' }
    },
    {
      path: '*',
      redirect: { name: '404' }
    }
  ]
});
router.beforeEach((to, from, next) => {
  let _isLogin = isLogin();
  if (to.matched.some(record => !record.meta.noCheckSession)) {
    if (!_isLogin) {
      next({
        path: '/login'
      });
    } else {
      if (checkMenu(to)) {
        if (to.matched.some(record => record.meta.needProject && !store.state.common.projectList.length)) {
          next({
            name: "projectError"
          });
        } else {
          next()
        }
      } else {
        next({
          path: '/404'
        });
      }
    }
  } else {
    if (!_isLogin) {
      next();
    } else {
      next({
        path: '/kfs'
      });
    }
  }
});
export default router;
