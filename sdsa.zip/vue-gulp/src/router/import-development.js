module.exports = file => require('@/' + file + '.vue').default;
