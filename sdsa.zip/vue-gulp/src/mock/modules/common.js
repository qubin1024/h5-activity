import Mock from 'mockjs'


export function getLogData() {
  return {
    url: 'getLogData',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {
        total: 1,
        list: [{
          taskName: 'cesi',
          startTime: '211',
          endTime: 'sdasd',
          status: '0',
          reason: 'csjkajdksahdsa'
        }]
      }
    }
  }
}
export function getTaskData() {
  return {
    url: 'getTaskData',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {
        total: 1,
        list: [{
          taskId: '1',
          serviceName: 'cesi',
          taskName: 'dsa',
          cron: 'sdasd',
          type: '0',
          status: '0',
          reason: "sdsadsa"
        }]
      }
    }
  }
}
export function getRoleData() {
  return {
    url: 'getRoleData',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {
        total: 1,
        list: [{
          roleName: "黄龙龙",
          system: "K-AFS",
          remarks: "这是一条测试数据"
        }]
      }
    }
  }
}

export function getUserData() {
  return {
    url: 'getUserData',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {
        total: 1,
        list: [{
          account: "carrqu",
          name: "瞿斌",
          phone: "15252778892",
          type: "AD",
          mail: "carr.qu@kpmg.com",
          remarks: "这是一条测试数据"
        }]
      }
    }
  }
}

export function getCustomById() {
  return {
    url: 'getCustomById',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {
        json: {
          title: '测试',
          type: 'line',
          sql: [{
            xAxis: [],
          }, {
            yAxis: [],
          }]
        },
        xAxis: ['1', '2', '3'],
        yAxis: ['222', '561', '345'],
      }
    }
  }
}
export function getMgrMenuList() {
  return {
    url: 'getMgrMenuList',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: [{
        icon: 'el-icon-menu',
        title: '数据加载',
        path: 'dataload',
        children: []
      }, {
        icon: 'el-icon-star-on',
        title: '角色管理',
        path: 'roleMgr',
        children: []
      }, {
        icon: 'el-icon-star-on',
        title: '用户管理',
        path: 'userMgr',
        children: []
      }, {
        icon: 'el-icon-star-on',
        title: '任务中心',
        path: 'taskCenter',
        children: []
      }]
    }
  }
}
export function updateProject() {
  return {
    url: 'updateProject',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {}
    }
  }
}
export function deleteProject() {
  return {
    url: 'deleteProject',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {}
    }
  }
}
export function addProject() {
  return {
    url: 'addProject',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {}
    }
  }
}
export function queryDataLoadData() {
  return {
    url: 'queryDataLoadData',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {
        total: 2,
        list: [{
          projectId: 2313213,
          projectName: "项目一",
          erp: "SAP",
          status: 0
        }, {
          projectId: 231223113,
          projectName: "项目二",
          erp: "SAP",
          status: 0
        }]
      }
    }
  }
}


export function saveFormData() {
  return {
    url: 'saveFormData',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {}
    }
  }
}

export function getFormData() {
  return {
    url: 'getFormData',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {
        name: 'ceshi',
        system: 'KFS',
        des: '这是一个测试模型',
        steps: [{
          script: '',
          params: '',
          type: 'sql',
          des: '大苏打撒旦'
        }]
      }
    }
  }
}


export function deleteNode() {
  return {
    url: 'deleteNode',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {}
    }
  }
}

// export function getTree () {
//   return {
//     url: 'getTree',
//     type: 'post',
//     param:{},
//       data: {
//         code: 0,
//         msg: 'success',
//         data: [{
//           id: 1,
//           label: 'KFS',
//           type: 1,
//           parentId: -1,
//           parentName: '',
//           children: [{
//             id: 4,
//             label: '模型一',
//             parentId: 1,
//             parentName: 'KFS',
//             type: 0
//           }]
//         }, {
//           id: 2,
//           label: 'MAOS',
//           parentId: -1,
//           parentName: '',
//           type: 1,
//           children: [{
//             id: 5,
//             label: '模型一',
//             parentId: 2,
//             parentName: 'MAOS',
//             type: 0
//           },{
//             id: 6,
//             label: '模型二',
//             parentId: 2,
//             parentName: 'MAOS',
//             type: 0
//           },{
//             id: 7,
//             label: '模型三',
//             parentId: 2,
//             parentName: 'MAOS',
//             type: 0
//           }]
//         }]
//       }
//     }
//   }

export function queryKfsReport() {
  return {
    url: 'queryKfsReport',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {}
    }
  }
}


export function addReportForm() {
  return {
    url: 'addReportForm',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {}
    }
  }
}

export function addTaskForm() {
  return {
    url: 'addTaskForm',
    type: 'post',
    param: {},
    data: {
      code: 200,
      msg: 'success',
      data: {}
    }
  }
}

export function queryKfsReportTable() {
  return {
    url: 'queryKfsReportTable',
    type: 'post',
    param: {
      username: "huang",
      password: "1234"
    },
    data: {
      code: 200,
      msg: 'success',
      data: {
        list: [{
          taskname: "任务1",
          taskdes: "这是一条测试任务",
          preTime: "2018-10-11",
          nextTime: "2018-01-31"
        }],
        total: 1
      }
    }
  }
}

export function login() {
  return {
    url: 'userManager/checkLogin',
    type: 'post',
    param: {
      username: "huang",
      password: "1234"
    },
    data: {
      code: 0,
      expire: 60 * 1000,
      msg: 'success',
      token: Mock.Random.guid(),
    }
  }
}

// export function getMenuList() {
//   return {
//     url: 'getMenuList',
//     type: 'post',
//     param: {
//       username: "huang",
//       password: "1234"
//     },
//     data: {
//       code: 200,
//       msg: 'success',
//       data: [{
//         icon: 'el-icon-menu',
//         title: '任务管理',
//         path: 'kfsTaskMgr',
//         children: []
//       }, {
//         icon: 'el-icon-document',
//         title: '报表查看',
//         path: 'kfsReport',
//         children: []
//       }, {
//         icon: 'el-icon-document',
//         title: '自定义报表',
//         path: 'kfsCustom',
//         children: []
//       }]
//     }
//   }
// }

// export function getMaosMenuList() {
//   return {
//     url: 'getMaosMenuList',
//     type: 'post',
//     param: {
//       username: "huang",
//       password: "1234"
//     },
//     data: {
//       code: 200,
//       msg: 'success',
//       data: [
//         {
//           icon: 'el-icon-document',
//           title: 'Maos报表',
//           path: 'maosReport',
//           children: []
//         },
//         {
//           icon: 'el-icon-document',
//           title: '自定义报表',
//           path: 'maosCustom',
//           children: []
//         }]
//     }
//   }
// }


