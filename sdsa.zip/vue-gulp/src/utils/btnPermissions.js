import Vue from 'vue';
import store from '@/store';
import _ from 'lodash';
/** 权限指令 **/
const has = Vue.directive('has', {
  bind: function (el, binding, vnode) {
    // 获取页面按钮权限
    if (typeof binding.value === 'object' && !!binding.value.key) {
      let btnPermissionsStr = binding.value.key;
      if (!Vue.prototype.$_has(btnPermissionsStr)) {
        if (!!el.parentNode) {
          el.parentNode.removeChild(el);
        } else {
          //dom还没有完全渲染出来的时候，采用的解决方法
          setTimeout(() => {
            el.parentNode.removeChild(el)
          }, 0)
        }
      }
    }
  }
})

const focus = Vue.directive('focus', {
  inserted: function (el) {
    // 聚焦元素
    el.querySelector('textarea').focus();
  }
})

Vue.directive('loadmore', {
  bind(el, binding) {
    // eslint-disable-next-line one-var
    let wrapper = null,
      selectWrap = el.querySelector('.el-table__body-wrapper'),
      selectWrap2 = el.querySelector('.el-scrollbar__wrap'),
      _function = _.debounce(binding.value, 1000, { leading: true, trailing: false }),
      sign = 1,
      scrollDown = false,
      _offset = 0;

    wrapper = selectWrap || selectWrap2;

    wrapper.addEventListener('scroll', function () {
      const scrollDistance = this.scrollHeight - this.scrollTop - this.clientHeight;

      // 判断是否向下滚动
      scrollDown = this.scrollTop - _offset > 0;
      _offset = this.scrollTop;

      // 如果滚动到底部
      if (scrollDistance <= sign && (this.scrollHeight !== this.clientHeight) && scrollDown) {
        _function();
      }
    });
  }
});

Vue.directive('listloadmore', {
  bind(el, binding) {
    const selectWrap = el;
    selectWrap.addEventListener('scroll', function () {
      let sign = 0;
      const scrollDistance = this.scrollHeight - this.scrollTop - this.clientHeight;
      if (scrollDistance <= sign && (this.scrollHeight !== this.clientHeight)) {
        binding.value();
      }
    });
  }
});


// 权限检查方法
Vue.prototype.$_has = function (value) {
  let btnPermissionsArr = store.state.common.btnPermissionsArr

  let isExist = false
  // 获取用户按钮权限
  if (value === undefined || value == null) {
    return false
  }
  if (btnPermissionsArr.indexOf(value) > -1) {
    isExist = true
  }

  return isExist
}

export { has }
