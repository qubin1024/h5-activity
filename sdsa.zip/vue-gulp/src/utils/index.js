import * as _ from "lodash"
import jsSHA from "jssha"
import CryptoJS from 'crypto-js';
import { Message } from 'element-ui';
import store from '@/store';
/**
 * 是否有权限
 * @param {*} key
 */
function isAuth(key) {
  return JSON.parse(sessionStorage.getItem('permissions') || '[]').indexOf(key) !== -1 || false
}

/**
 * 获取路由名称, 根据url地址
 * @param {*} url
 */
function getRouteNameByUrl(url) {
  let val = /.*\/(.*)\.html/.exec(url)
  return val && val.length >= 1 ? val[1] : ''
}

/**
 * 树形数据转换
 * @param {*} data
 * @param {*} id
 * @param {*} pid
 */
function treeDataTranslate(data, id = 'id', pid = 'parentId') {
  var res = []
  var temp = {}
  for (var i = 0; i < data.length; i++) {
    temp[data[i][id]] = data[i]
  }
  for (var k = 0; k < data.length; k++) {
    if (temp[data[k][pid]] && data[k][id] !== data[k][pid]) {
      if (!temp[data[k][pid]]['children']) {
        temp[data[k][pid]]['children'] = []
      }
      if (!temp[data[k][pid]]['_level']) {
        temp[data[k][pid]]['_level'] = 1
      }
      data[k]['_level'] = temp[data[k][pid]]._level + 1
      temp[data[k][pid]]['children'].push(data[k])
    } else {
      res.push(data[k])
    }
  }
  return res
}

/**
 * 获取字符串字节长度
 * @param {*} s
 */
function getStringLength(s) {
  return s.replace(/[\u4e00-\u9fa5\uff00-\uffff]/g, '**').length
}

/**
 * 生成uuid
 */
var getUUID = (function () {

  // http://stackoverflow.com/questions/105034/how-to-create-a-guid-uuid-in-javascript/21963136#21963136

  var lut = [];

  for (var i = 0; i < 256; i++) {

    lut[i] = (i < 16 ? '0' : '') + (i).toString(16);

  }

  return function generateUUID() {

    var d0 = Math.random() * 0xffffffff | 0;
    var d1 = Math.random() * 0xffffffff | 0;
    var d2 = Math.random() * 0xffffffff | 0;
    var d3 = Math.random() * 0xffffffff | 0;
    var uuid = lut[d0 & 0xff] + lut[d0 >> 8 & 0xff] + lut[d0 >> 16 & 0xff] + lut[d0 >> 24 & 0xff] +
      lut[d1 & 0xff] + lut[d1 >> 8 & 0xff] + lut[d1 >> 16 & 0x0f | 0x40] + lut[d1 >> 24 & 0xff] +
      lut[d2 & 0x3f | 0x80] + lut[d2 >> 8 & 0xff] + lut[d2 >> 16 & 0xff] + lut[d2 >> 24 & 0xff] +
      lut[d3 & 0xff] + lut[d3 >> 8 & 0xff] + lut[d3 >> 16 & 0xff] + lut[d3 >> 24 & 0xff];

    // .toUpperCase() here flattens concatenated strings to save heap memory space.
    return uuid.toUpperCase();

  };
})()


/**
 * 生成uuid16
 */
var getUUID16 = (function () {

  // http://stackoverflow.com/questions/105034/how-to-create-a-guid-uuid-in-javascript/21963136#21963136

  var lut = [];

  for (var i = 0; i < 256; i++) {

    lut[i] = (i < 16 ? '0' : '') + (i).toString(16);

  }

  return function generateUUID16() {

    var d0 = Math.random() * 0xffffffff | 0;
    var d1 = Math.random() * 0xffffffff | 0;
    var uuid = lut[d0 & 0xff] + lut[d0 >> 8 & 0xff] + lut[d0 >> 16 & 0xff] + lut[d0 >> 24 & 0xff] +
      lut[d1 & 0xff] + lut[d1 >> 8 & 0xff] + lut[d1 >> 16 & 0x0f | 0x40] + lut[d1 >> 24 & 0xff];

    // .toUpperCase() here flattens concatenated strings to save heap memory space.
    return uuid.toUpperCase();

  };
})()


/**
 * 通用的日期格式化方法
 * @export
 * @param {*} date -Date类型的实例
 * @param {string} [fmt='yyyy-MM-dd hh:mm:ss']
 * @returns 格式化之后的字符串形式
 */
function dateFormat(date, fmt = 'yyyy-MM-dd hh:mm:ss') {
  if (!(date instanceof Date)) throw new Error("invalid date format")
  let o = {
    "M+": date.getMonth() + 1, //月份
    "d+": date.getDate(), //日
    "h+": date.getHours(), //小时
    "m+": date.getMinutes(), //分
    "s+": date.getSeconds(), //秒
    "q+": Math.floor((date.getMonth() + 3) / 3), //季度
    "S": date.getMilliseconds() //毫秒
  };
  if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
  return fmt;
}

function delay(seconds) {
  return new Promise(function (resolve, reject) {
    setTimeout(() => resolve(), seconds)
  })
}

/**
 * 校验备注信息，不能含有"="，防止出现sql注入
 * 出现"=",提示异常
 */
function validateComment(rule, value, callback) {
  // console.log("value2:",value);
  return (/[=]/.test(value));
}

/**
 * 高阶函数,对指定的函数取反
 * @param {func} f -匿名函数
 * @returns 传入的匿名函数的取反
 */
function not(f) {
  if (!f instanceof Function) throw new Error(' parameter should be a function!');
  return function () {
    return !f.apply(null, arguments);
  }
}

/**
 *交换一个数组中两个元素的位置
 * @param {Array} arr -目标数组
 * @param {int} x  -下标1
 * @param {int} y  -下标2
 * @returns 新数组
 */
function swapElement(arr, x, y) {

  if (arr instanceof Array && arr.length === 0) return [];

  if (typeof x !== 'number' || typeof y !== 'number') throw new TypeError('must be number')

  if (x === y) return arr

  if (x < 0 || y < 0 || x > arr.length || y > arr.length) throw new Error('invalid parameter')

  let _arr = _.cloneDeep(arr), _temp = null;

  _temp = _arr[x];

  _arr[x] = _arr[y];

  _arr[y] = _temp;

  return _arr
}


/**
 * 两个不同的颜色按照一定的比例混合,和GLSL的中的mix函数类似
 * @param {number} p  -0-1的小数
 * @param {string} c0  -16进制颜色值 例如:"#ff0000"
 * @param {string} c1 -16进制颜色值 例如:"#ff0000"
 * @returns c1 -16进制颜色值 例如:"#ff0000"
 */
function colorMix(p, c0, c1) {

  var n = p < 0 ? p * -1 : p,
    u = Math.round,
    w = parseInt;
  if (c0.length > 7) {
    var f = c0.split(","),
      t = (c1 ? c1 : p < 0 ? "rgb(0,0,0)" : "rgb(255,255,255)").split(","),
      R = w(f[0].slice(4)),
      G = w(f[1]),
      B = w(f[2]);
    return "rgb(" + (u((w(t[0].slice(4)) - R) * n) + R) + "," +
      (u((w(t[1]) - G) * n) + G) + "," + (u((w(t[2]) - B) * n) + B) + ")"
  } else {
    var f = w(c0.slice(1), 16),
      t = w((c1 ? c1 : p < 0 ? "#000000" : "#FFFFFF")
        .slice(1), 16),
      R1 = f >> 16,
      G1 = f >> 8 & 0x00FF,
      B1 = f & 0x0000FF;
    return "#" + (0x1000000 + (u(((t >> 16) - R1) * n) + R1) *
      0x10000 + (u(((t >> 8 & 0x00FF) - G1) * n) + G1) * 0x100 +
      (u(((t & 0x0000FF) - B1) * n) + B1)).toString(16).slice(1)
  }
}


let tipSuccess = function (message) {
  this.commit("UPDATE_MESSAGE_BOX", Object.assign({ type: "success" }, { message, toStored: false }))
}
let tipError = function (message) {
  this.commit("UPDATE_MESSAGE_BOX", Object.assign({ type: "error" }, { message, toStored: false }))
}
let tipWarn = function (message) {
  this.commit("UPDATE_MESSAGE_BOX", Object.assign({ type: "warning" }, { message, toStored: false }))
}


/**
 *rgb颜色值转换为16进制颜色
 * @param {*} rgb -rgb颜色值 如 rbg(255,0,0)
 * @returns
 * @example
 *
 *  var red='rgb(255,0,0)';
 *  rgb2hex(red) should return '#ff0000'
 */
function rgb2hex(rgb) {
  var reg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;
  if (/^(rgb|RGB)/.test(rgb)) {
    var aColor = rgb.replace(/(?:\(|\)|rgb|RGB)*/g, "").split(",");
    var strHex = "#";
    for (var i = 0; i < aColor.length; i++) {
      var hex = Number(aColor[i]).toString(16);
      if (hex.length < 2) {
        hex = '0' + hex;
      }
      strHex += hex;
    }
    if (strHex.length !== 7) {
      strHex = rgb;
    }
    return strHex;
  } else if (reg.test(rgb)) {
    var aNum = rgb.replace(/#/, "").split("");
    if (aNum.length === 6) {
      return rgb;
    } else if (aNum.length === 3) {
      var numHex = "#";
      for (var i = 0; i < aNum.length; i += 1) {
        numHex += (aNum[i] + aNum[i]);
      }
      return numHex;
    }
  }
  return rgb;
};

/**
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/findIndex
 *  this method returns the index of the first element in the array that satisfies
 *  the provided testing function. Otherwise -1 is returned.
 * @param {Array} arr
 * @param {function} predicate -Function to execute on each value in the array, taking three arguments
 * @param {object} thisArg -Optional. Object to use as this when executing callback.
 * @returns An index in the array if an element passes the test; otherwise, -1.
 */
function findIndex(arr, predicate, thisArg) {
  // 1. Let O be ? ToObject(this value).
  if (arr == null) {
    throw new TypeError('arr is null or not defined');
  }

  var o = Object(arr);

  // 2. Let len be ? ToLength(? Get(O, "length")).
  var len = o.length >>> 0;

  // 3. If IsCallable(predicate) is false, throw a TypeError exception.
  if (typeof predicate !== 'function') {
    throw new TypeError('predicate must be a function');
  }

  // 4. If thisArg was supplied, let T be thisArg; else let T be undefined.
  var thisArg = arguments[2];

  // 5. Let k be 0.
  var k = 0;

  // 6. Repeat, while k < len
  while (k < len) {
    // a. Let Pk be ! ToString(k).
    // b. Let kValue be ? Get(O, Pk).
    // c. Let testResult be ToBoolean(? Call(predicate, T, « kValue, k, O »)).
    // d. If testResult is true, return k.
    var kValue = o[k];
    if (predicate.call(thisArg, kValue, k, o)) {
      return k;
    }
    // e. Increase k by 1.
    k++;
  }

  // 7. Return -1.
  return -1;
}


function tableHeaderStyle() {
  return {
    fontSize: "1.2rem",
    textAlign: "left",
    padding: "8px 0",
    height: "45px"
  };
}

function isIE() {
  return (navigator.userAgent.indexOf("MSIE") != -1 || (!!document.documentMode == true))
}

function validateName(rule, value, callback) {
  if (value === '') {
    callback(new Error("名称不能为空"));
  } else if (/[\s^%&',;=?\\]/.test(value)) {
    callback(new Error('名称非法定义'));
  } else if (value.length > 25) {
    callback(new Error('名称长度太长'))
  }
  else {
    callback();
  }
}



/**
 *根据动态表头的辅助维度生成参数
 * @param {number} index -拼名字的数字
 * @param {Object} value -参考值
 * @returns {Object}
 * @example   buildParamName(1)====>{
 *     "SEG1": "",
       "SEG1_CD": "",
       "SEG1_NM": "部门合计",
 * }
 */
function buildParamName(index, { cname }) {
  let _prefix = "SEG",
    _prefixCd = 'CD',
    _prefixNm = 'NM',
    _obj = {},
    _descriptor = (value = '') => ({
      value,
      configurable: true,
      enumerable: true,
      writable: true
    })


  Object.defineProperty(_obj, _prefix + index, _descriptor());

  Object.defineProperty(_obj, _prefix + index + "_" + _prefixCd, _descriptor());

  Object.defineProperty(_obj, _prefix + index + "_" + _prefixNm, _descriptor(cname));

  return _obj;

}

//根据动态表头的个数动态生成参数
function generateTableHeader(data) {

  let getViceHeaders = (v, i) => v.isDim === '1' && i > 0,

    mapper = (v, i) => buildParamName(++i, v),

    reducer = _.curry((curr, next) => ({ ...curr, ...next })),

    wrapTo = _.curry((to, prop, object) => {
      if (to === null) to = new Object;
      Object.defineProperty(to, prop, {
        value: object,
        configurable: true,
        enumerable: true,
        writable: true
      })
      return to
    });

  let findViceHeaders = filter(getViceHeaders),
    mapped = map(mapper),
    reduce = reduceLeft({}),
    wrapper = wrapTo(null, 'auxDim');

  return _.flow(findViceHeaders, mapped, reduce(reducer), wrapper)(data);

}




let filter = _.curry((f, arr) => {
  if (arr === null || arr === undefined) arr = [];

  if (!arr instanceof Array) throw new Error('arr should be an Array');

  return arr.filter(f)
});

let reduceLeft = _.curry((init, f, arr) => {
  if (arr === null || arr === undefined) arr = [];

  if (!arr instanceof Array) throw new Error('arr should be an Array');

  return arr.reduce(f, init)
});
let map = _.curry((f, arr) => {
  if (arr === null || arr === undefined) arr = [];

  if (!arr instanceof Array) throw new Error('arr should be an Array');

  return arr.map(f)
});



function getValid(params) {
  const paramsValue = {
    ...params,

  }
  let _isEmpty = (property) => property === null || property === undefined || property === '';

  let _hasCompanyName = _.curry((list) => {
    if (_isEmpty(paramsValue.corpNm) || _isEmpty(paramsValue.corpCd)) throw new Error("公司名称不能为空");
    return list;
  });
  let _hasDate = _.curry((list) => {
    if (_isEmpty(paramsValue.startDate) || _isEmpty(paramsValue.endDate)) throw new Error("日期选择不能为空");
    return list;
  });
  let validate = _.flow(_hasCompanyName, _hasDate);

  validate(paramsValue);
}

/**
 * 校验备注信息，不能含有"="，防止出现sql注入
 * 出现"=",提示异常
 */
function validateComment(rule, value, callback) {
  // console.log("value2:",value);
  return (/[=]/.test(value));
}

function generateSHA(str) {
  let shaObj = new jsSHA("SHA-256", "TEXT");
  shaObj.update(str);
  return shaObj.getHash("HEX");
}


/**
 * 基于 AES /ECB/Pkcs5padding的加密算法
 * @param {*} content 需要加密的字符串
 * @returns
 */
function encrypt(content) {
  let key = CryptoJS.enc.Utf8.parse("kpmgdatalakeaesk"),
    srcs = CryptoJS.enc.Utf8.parse(content);
  var encryptResult = CryptoJS.AES.encrypt(srcs, key, {
    mode: CryptoJS.mode.ECB,
    padding: CryptoJS.pad.Pkcs7
  });
  return encryptResult.toString();
}

function isLogin(name) {
  try {
    return /login/g.test(document.cookie) && store.state.common.login === true
  } catch (e) {
    console.error(e.message)
    return false
  }
}

function checkError(res, callback) {
  try {
    if (res.code == 200) {
      if (typeof callback == "function")
        callback(res);
    } else {
      //console.error(res.msg);
      Message.error({
        message: res.msg
      })
    }
  } catch (e) {
    console.error(e.message)
    return false;
  }
}

function checkMenu(to) {
  return true || !(store.state.common.menuList.indexOf(to.name) === -1)
}

Date.prototype.Format = function (fmt) {
  var o = {
    "M+": this.getMonth() + 1,                 //月份
    "d+": this.getDate(),                    //日
    "h+": this.getHours(),                   //小时
    "m+": this.getMinutes(),                 //分
    "s+": this.getSeconds(),                 //秒
    "q+": Math.floor((this.getMonth() + 3) / 3), //季度
    "S": this.getMilliseconds()             //毫秒
  };
  if (/(y+)/.test(fmt))
    fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
  for (var k in o)
    if (new RegExp("(" + k + ")").test(fmt))
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
  return fmt;
}

export function formatTimeToStr(times, pattern) {
  var d = new Date(times).Format("yyyy-MM-dd hh:mm:ss");
  if (pattern) {
    d = new Date(times).Format(pattern);
  }
  return d.toLocaleString();
}

function getApp() {
  return window.location.href.match(/\/#\/\w*/)[0].match(/\w+/)[0]
}

export {
  isAuth,
  getRouteNameByUrl,
  treeDataTranslate,
  getStringLength,
  getUUID,
  getUUID16,
  delay,
  dateFormat,
  tipSuccess,
  tipError,
  tipWarn,
  not,
  swapElement,
  colorMix,
  getValid,
  rgb2hex,
  tableHeaderStyle,
  validateName,
  isIE,
  isLogin,
  findIndex,
  filter,
  reduceLeft,
  map,
  buildParamName,
  generateTableHeader,
  validateComment,
  generateSHA,
  encrypt,
  checkMenu,
  getApp,
  checkError
}
