<template>
	<div ref="selectWrap" class="select-wrap">
		<span :data-id="data.id" :title="data.title" class="hll-head" >{{(connect&&data.id)?(data.id+"-"+data.title):data.title}}</span>
		<i :class="{'is-reverse': shown}" @click.stop="click" class="el-select__caret el-input__icon el-icon-arrow-up"></i>
		<transition name="fade">
			<div ref="dropdownWrap" v-show="shown" class="dropdown hll-drop-down" :style="dropdownStyle" @click.stop="()=>{}"  :class="{up: isup}">
				<div class="popper__arrow"></div>
				<div class="select-content" >
					<div class="seach-input">
						<el-input size="mini" style="width:100%; padding: 0;line-height: 30px;" :placeholder="searchPlaceholder" v-model='searchParam' @keyup.enter.native="searchAjax" suffix-icon="el-icon-search" ></el-input>
					</div>
					<div v-loading="loading" style="padding: 0;display: block;">
						<ul  v-listloadmore="loadMore" style="width:380px" class="ul-list">
							<li class="none" v-if="isNone">{{$t('msg-no-data')}}</li>
							<li v-if="!isNone"  :data-id="data.id"  :data-title="data.title"  @click="clearInput">{{$t('text-no-option')}}</li>
							<li v-for="item in listData" :key="item.code" :data-id="item.code"  :data-title="item.value" :data-level="item.sbjLevel"   :data-type="types" @click="select">
						    	{{(showItemCode ? '（' + item.code + '）' : '') + item.value}}
						    </li>
						</ul>
					</div>
				</div>
			</div>
		</transition>
	</div>
</template>

<script>
import API from "@/api";
import { tipSuccess, tipError, tipWarn } from "@/utils/index.js";
export default {
  name: "select-ajax-table",
  data: function() {
    return {
      shown: false,
      searchParam: "",
      size: 10,
      page: 1,
      isup: false,
      more: false,
      loading: false,
      listData: [],
      dropdownStyle: {
        top: 0,
        left: 0,
        height: 270
      }
    };
  },
  props: {
    action: Function,
    defaultData: {
      type: Object,
      default: function() {
        return {
          id: "",
          title: this.$t("text-default"),
          _id:'',
          _title:''
        };
      }
    },
    searchPlaceholder: {
      type: String,
      default: function() {
        return this.$t("button-search");
      }
    },
    types: {
      type: String,
      default: function() {
        return "dafault";
      }
    },
    queryParam: {
      type: Object,
      default: function() {
        return {};
      }
    },
    showItemCode: {
      type: Boolean,
      default: function() {
        return true;
      }
    },
    connect:{
      type:Boolean,
      default:function(){
        return false
      }
    }
  },
  computed: {
    isNone: function() {
      return !this.listData.length;
    },
    data: function() {
      return {
		  id:this.defaultData.id,
		  title:this.defaultData.title,

		  _id:this.defaultData._id,
		  _title:this.defaultData._title,
	  } 
    },
    showTitle:function(){
      let {id,title}=this.data;
      alert(this.connect)
      return (this.connect&&id)?(id+"-"+title):title
    }
  },
  mounted() {
    var that = this;
    window.onresize = function() {
      that.getPosition();
    };

    document.addEventListener("click", this.documentclick, false);
  },
  destroyed() {
    window.onresize = null;
    document.removeEventListener("click", this.documentclick, false);
  },
  methods: {
    show(){
      this.shown = true;

  	  this.removeChildList(document.body,document.querySelectorAll("body>.hll-drop-down"));

      document.body.appendChild(this.$refs.dropdownWrap);

    },
    hide(){
      this.shown = false;

	    this.removeChildList(document.body,document.querySelectorAll("body>.hll-drop-down"));

    },
    documentclick(e) {
      this.hide();
      this.page = 1;
      this.searchParam = "";
      this.more = false;
    },
    click(e) {
      if (this.shown) {
        this.hide();
        this.page = 1;
        this.searchParam = "";
        this.more = false;
      } else {
        this.show();
        this.getPosition();
        this.searchAjax();
      }
    },
    select(e) {
      this.data.title = e.target.dataset.title;
      this.data.id = e.target.dataset.id;
      this.data.level=e.target.dataset.level;
      this.hide()
      this.$emit("listSelectCallback", e.target.dataset);
    },
    clearInput(e) {
      this.data.id = this.defaultData._title?'':this.defaultData.id;
      this.data.title = this.defaultData._title?this.defaultData._title:this.defaultData.title;

      this.hide()
      this.$emit("listSelectCallback", {
        type: this.types,
        id: -1,
        title: this.data.title,
        level:''
      });

      // console.log(this.defaultData)
      // if(!!this.data.id && this.data.id != ''){
      // 	this.data.id = '';
      // 	this.data.title = this.types == 'group' ? '组团合计': (this.types == 'department' ? '部门合计': (this.types == 'counter' ? '交易对手合计' :(this.types == 'subject' ? '科目' : '')));
      // 	this.shown = false;
      // 	this.$emit('listSelectCallback', {
      // 		type: this.types,
      // 		id: "",
      // 		title: this.data.title
      // 	});
      // }
    },
    cpCallback(dims, more) {
      this.listData = dims;
      this.more = more;
      this.page++;
    },
    cpLoadingCallback(dims, more) {
      var that = this;
      dims.forEach(function(data) {
        that.listData.push(data);
      });
      that.more = more;
      that.page++;
    },
    getPosition() {
      let {
        left,
        right,
        top,
        bottom
      } = this.$refs.selectWrap.getBoundingClientRect();
      let winHeight = window.innerHeight,
        elWidth = right - left,
        elHeight = bottom - top,
        downStyle = {
          ...this.dropdownStyle,
          left: left + "px",
          top: bottom + 10 + "px"
        };

        this.isup = false;
        this.dropdownStyle = downStyle;
    },
    loadMore: async function() {
      if (this.loading || !this.more) {
        return;
      }
      this.loading = true;
      try {
        var that = this;
        var params = {
          pageSize: that.size,
          pageNum: that.page,
          projectId: this.$root.$store.state.common.params.projectId,
          queryParam: that.searchParam,
          ...this.queryParam
        };
        let { data: { data, msg, status } } = await that.action()(params);
        if (status === 0) {
          that.cpLoadingCallback(data.list, data.hasNextPage);
        }
        that.loading = false;
      } catch (e) {
        throw new Error(e);
      }
    },
    searchAjax: async function() {
      try {
        var that = this;
        that.page = 1;
        that.listData = [];
        if (that.searchParam.length > 50) {
          tipWarn.call(this.$store, "输入内容不能超过50字符！");
          return;
        }
        var params = {
          pageSize: that.size,
          pageNum: that.page,
          projectId: this.$root.$store.state.common.params.projectId,
          queryParam: that.searchParam,
          ...this.queryParam
        };

        this.loading = true;
        let { data: { data, msg, status } } = await that.action()(params);
        if (status === 0) {
          that.cpCallback(data.list, data.hasNextPage);
        }
        that.loading = false;
      } catch (e) {
        throw new Error(e);
      }
    },
    removeChildList(parent, children) {
      for (let i = 0; i < children.length; i++) {
		  parent.removeChild(children[i]);
	  }
    }
  }
};
</script>

<style scoped>
.select-wrap {
  position: relative;
  padding-right: 28px;
  padding-left: 0;
  word-wrap: normal;
  text-overflow: ellipsis;
  display: inline-block;
  vertical-align: middle;
  width: calc(100% - 0px);
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  white-space: nowrap;
  word-break: normal;
  line-height: 23px;
  overflow: hidden;
}
.el-icon-arrow-up:before {
  content: "\E60C";
  color: #404040 !important;
}
.select-wrap > i {
  position: absolute;
  right: 4px;
  top: 1px;
  color: #c0c4cc;
  font-size: 14px;
  -webkit-transition: -webkit-transform 0.3s;
  transition: -webkit-transform 0.3s;
  transition: transform 0.3s;
  transition: transform 0.3s, -webkit-transform 0.3s;
  transition: transform 0.3s, -webkit-transform 0.3s;
  -webkit-transform: rotateZ(180deg);
  transform: rotateZ(180deg);
  line-height: 16px;
  cursor: pointer;
}
.select-wrap > i.is-reverse {
  -webkit-transform: rotateZ(0);
  transform: rotateZ(0);
}

.popper__arrow {
  top: -6px;
  left: 50%;
  margin-right: 3px;
  border-top-width: 0;
  display: flex;
  border-bottom-color: #ebeef5;
}
.up .popper__arrow::after {
  top: auto;
  bottom: -5px;
  border-bottom-width: 0;
  border-top-color: #fff;
  border-top-width: 6px;
}
.popper__arrow::after {
  content: " ";
  border-width: 6px;
  position: absolute;
  display: block;
  width: 0;
  height: 0;
  border-color: transparent;
  border-style: solid;
  top: -5px;
  left: 30px;
  margin-left: -6px;
  border-top-width: 0;
  border-bottom-color: #fff;
}
.select-content {
  padding: 5px;
  display: block;
}
.ul-list {
  list-style: none;
  padding: 0;
  padding: 5px;
  margin: 0;
  max-height: 200px;
  overflow: auto;
}
.ul-list li {
  white-space: nowrap;
  overflow: hidden;
  height: 30px;
  line-height: 20px;
  cursor: pointer;
  padding: 5px;
  border-radius: 4px;
  transition: all 0.5s ease;
  font-weight: normal;
  max-width: 360px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-size:14px;
  color:#777
}
.ul-list li:hover {
  background: #409eff;
  color: #ffffff;
}
li.none {
  text-align: center;
  color: #cccccc;
}
li.none:hover {
  background: none;
  color: #cccccc;
  cursor: auto;
}
.el-loading-spinner {
  width: calc(100% - 20px);
}
.seach-input {
  height: 40px;
  padding: 5px 0;
  display: block;
}
.setheight {
  overflow: hidden;
  height: 300px;
}
.el-loading-spinner {
  width: calc(100% - 20px);
}

.hll-head{
  display: inline-block;
  overflow: hidden;
  text-overflow:ellipsis;
  vertical-align: top;
  max-width: 100px;
}
</style>
