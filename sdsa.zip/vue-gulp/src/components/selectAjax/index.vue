<template>
  <div ref="selectWrap" class="select-wrap">
    <i class="close el-icon-circle-close" title="no-message-data" @click="historyReset"></i>
    <input type="text" ref='input' style="height: 100%;" :placeholder="placeholder" @click.stop="inputClick" v-model="data.title"
      :data-id="data.id" readonly/>
    <i :class="{'is-reverse': shown}" @click.stop="inputClick" class="el-select__caret el-input__icon el-icon-arrow-up"></i>
    <transition name="fade">
      <div v-show="shown" class="dropdown hll-drop-down" ref="dropdownWrap" @click.stop="()=>{}" :class="{up: isup}" :style="dropdownStyle">
        <div class="popper__arrow"></div>
        <div class="select-content">
          <div class="seach-input">
            <el-input size="mini" :style="styleObj" :placeholder="searchPlaceholder" v-model.trim='searchParam' @keyup.enter.native="searchAjax"
              suffix-icon="el-icon-search"></el-input>
          </div>
          <div v-loading="loading">
            <ul v-listloadmore="loadMore" style="width:380px" class="ul-list">
              <li class="none" v-if="isNone">{{$t('dataNone')}}</li>
              <li v-if="!isNone" @click="clearInput">No Select Option</li>
              <li v-for="item in listData" :key="item.code" :data-id="item.code" :data-title="item.value" @click="click(item, $event)">
                <!--{{'（' + item.code + '）' + item.value}}-->
                {{item.value}}
              </li>
            </ul>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
import API from "@/api";
import { tipSuccess, tipError, tipWarn, getApp } from "@/utils/index.js";
export default {
  name: "select-ajax",
  data: () => {
    return {
      shown: false,
      searchParam: "",
      default: this.defaultData,
      size: 10,
      page: 1,
      isup: false,
      more: false,
      loading: false,
      listData: [],
      dropdownStyle: {
        top: 0,
        left: 0,
        height: 270
      }
    };
  },
  props: {
    clearHistory: Function,
    placeholder: String,
    searchPlaceholder: {
      type: String,
      default: function() {
        return this.$t("button-search");
      }
    },
    action: Function,
    type: String,
    defaultData: {
      type: Object,
      default: function() {
        return {
          id: "",
          title: ""
        };
      }
    },
    queryParam: {
      type: Object,
      default: function() {
        return {};
      }
    }
  },
  computed: {
    styleObj() {
      return {
        width: "100%"
      };
    },
    isNone: function() {
      return !this.listData.length;
    },
    data: function() {
      return Object.assign({}, this.default);
    }
  },
  mounted() {
    this.default = this.defaultData;
    document.addEventListener("click", this.documentclick, false);
  },
  destroyed() {
    this.hide();
    document.removeEventListener("click", this.documentclick, false);
    console.log("selectAjax destory");
  },
  watch: {
    defaultData(newData) {
      this.default = newData;
    }
  },
  methods: {
    hide() {
      this.shown = false;
      this.removeChildList(
        document.body,
        document.querySelectorAll("body>.hll-drop-down")
      );
    },
    show() {
      this.shown = true;

      this.removeChildList(
        document.body,
        document.querySelectorAll("body>.hll-drop-down")
      );

      document.body.appendChild(this.$refs.dropdownWrap);
    },
    documentclick(e) {
      this.hide();
      this.page = 1;
      this.searchParam = "";
      this.more = false;
    },
    windowScroll() {},
    historyReset: function() {
      this.$refs.input.value = "";
      this.clearInput();

      if (this.clearHistory) this.clearHistory();
    },
    inputClick() {
      if (this.shown) {
        this.hide();
        this.page = 1;
        this.searchParam = "";
        this.more = false;
      } else {
        this.show();
        this.getPosition();
        this.searchAjax();
      }
    },
    click(item, e) {
      if (this.default.id != e.target.dataset.id) {
        this.default.title = e.target.dataset.title;
        this.default.id = e.target.dataset.id;
        this.$emit("listSelectCallback", e.target.dataset, item);
        this.hide();
      }
    },
    clearInput() {
      if (!!this.default.id && this.default.id != "") {
        this.default.title = "";
        this.default.id = "";
        this.hide();
        this.$emit("listSelectCallback", {
          id: "",
          title: ""
        });
      }
    },
    cpCallback(dims, more) {
      this.listData = dims;
      this.more = more;
      this.page++;
    },
    cpLoadingCallback(dims, more) {
      var that = this;
      dims.forEach(function(data) {
        that.listData.push(data);
      });
      that.more = more;
      that.page++;
    },
    getPosition() {
      let {
        left,
        right,
        top,
        bottom
      } = this.$refs.selectWrap.getBoundingClientRect();
      let winHeight = window.innerHeight,
        elWidth = right - left,
        elHeight = bottom - top,
        upStyle = {
          ...this.dropdownStyle,
          left: left + "px",
          top: top - this.dropdownStyle.height + "px"
        },
        downStyle = {
          ...this.dropdownStyle,
          left: left + "px",
          top: bottom + 10 + "px"
        };

      if (elHeight + top + this.dropdownStyle.height > winHeight) {
        this.isup = true;
        this.dropdownStyle = upStyle;
      } else {
        this.isup = false;
        this.dropdownStyle = downStyle;
      }

      if (winHeight < 400) {
        this.isup = false;
        this.dropdownStyle = downStyle;
      }
    },
    loadMore: async function() {
      if (this.loading || !this.more) {
        return;
      }
      this.loading = true;
      try {
        var that = this;
        var params = {
          pageSize: that.size,
          pageNum: that.page,
          // projectId: this.$root.$store.state.common.params.projectId,
          // userId: "83E25F780521408597BCF0A8C0795148",
          queryParam: that.searchParam,
          ...this.queryParam,
          appId: getApp()
          // ...this.queryParam
        };
        let { data: { data, msg, code } } = await that.action()(params);
        if (code === 200) {
          that.cpLoadingCallback(data.list, data.hasNextPage);
        } else {
          console.log(msg);
        }
        that.loading = false;
      } catch (e) {
        throw new Error("err");
      }
    },
    searchAjax: async function() {
      try {
        var that = this;
        that.page = 1;
        that.listData = [];
        that.listTableData = [];
        if (that.searchParam.length > 60) {
          tipWarn.call(this.$store, "搜索最大长度超过60");
          return;
        }
        var params = {
          pageSize: that.size,
          pageNum: that.page,
          queryParam: that.searchParam,
          appId: getApp(),
          // projectId: this.$root.$store.state.common.params.projectId,
          // userId: "83E25F780521408597BCF0A8C0795148",
          // queryParam: that.searchParam,
          // param: that.searchParam,
          ...this.queryParam
        };
        this.loading = true;
        let { data: { data, msg, code } } = await that.action()(params);
        if (code === 200) {
          that.cpCallback(data.list, data.hasNextPage);
        } else {
          console.log(msg);
        }
        that.loading = false;
      } catch (e) {
        throw new Error("err");
      }
    },
    removeChildList(parent, children) {
      for (let i = 0; i < children.length; i++) {
        parent.removeChild(children[i]);
      }
    }
  }
};
</script>

<style scoped>
.select-wrap {
  display: inline-block;
  height: 28px;
  width: 183px;
  position: relative;
}

.select-wrap input {
  -webkit-appearance: none;
  background-color: #fff;
  background-image: none;
  border-radius: 4px;
  border: 1px solid #dcdfe6;
  -webkit-box-sizing: border-box;
  box-sizing: border-box;
  color: #606266;
  display: inline-block;
  font-size: 12px;
  height: 40px;
  line-height: 1;
  outline: 0;
  padding: 0 15px;
  -webkit-transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
  width: 100%;
  height: 28px;
  cursor: pointer;
  padding-right: 45px;
}

.select-wrap input:focus {
  border-color: #409eff;
  outline: 0;
}

.select-wrap > .el-select__caret {
  position: absolute;
  right: 4px;
  top: 1px;
  color: #c0c4cc;
  font-size: 14px;
  -webkit-transition: -webkit-transform 0.3s;
  transition: -webkit-transform 0.3s;
  transition: transform 0.3s;
  transition: transform 0.3s, -webkit-transform 0.3s;
  transition: transform 0.3s, -webkit-transform 0.3s;
  -webkit-transform: rotateZ(180deg);
  transform: rotateZ(180deg);
  line-height: 16px;
  cursor: pointer;
}

.select-wrap > .close {
  display: none;
  position: absolute;
  right: 28px;
  top: 50%;
  margin-top: -13px;
  color: #c0c4cc;
  font-size: 14px;
  -webkit-transition: -webkit-transform 0.3s;
  transition: -webkit-transform 0.3s;
  transition: transform 0.3s;
  transition: transform 0.3s, -webkit-transform 0.3s;
  transition: transform 0.3s, -webkit-transform 0.3s;
  line-height: 27px;
  cursor: pointer;
}

.select-wrap:hover > .close {
  -webkit-transform: rotateZ(180deg);
  transform: rotateZ(180deg);
  display: block;
}

.select-wrap > i.is-reverse {
  -webkit-transform: rotateZ(0);
  transform: rotateZ(0);
}

.dropdown {
  position: fixed;
  z-index: 10001;
  min-width: 200px;
  min-height: 100px;
  border-radius: 4px;
  background: #ffffff;
  border: 1px solid #e4e7ed;
  box-shadow: 0 2px 12px 0 rgba(0, 0, 0, 0.1);
}

.up .popper__arrow::after {
  top: auto;
  bottom: -5px;
  border-bottom-width: 0;
  border-top-color: #fff;
  border-top-width: 6px;
}

.popper__arrow::after {
  content: " ";
  border-width: 6px;
  position: absolute;
  display: block;
  width: 0;
  height: 0;
  border-color: transparent;
  border-style: solid;
  top: -5px;
  left: 30px;
  margin-left: -6px;
  border-top-width: 0;
  border-bottom-color: #fff;
}

.select-content {
  padding: 5px;
}

.ul-list {
  list-style: none;
  padding: 0;
  padding: 5px;
  margin: 0;
  max-height: 200px;
  overflow: auto;
  color: #666;
  font-size: 14px;
}

.ul-list li {
  white-space: nowrap;
  overflow: hidden;
  height: 30px;
  line-height: 20px;
  cursor: pointer;
  padding: 5px;
  border-radius: 4px;
  transition: all 0.5s ease;
  max-width: 360px;
  text-overflow: ellipsis;
  font-size: 14px;
  color: #777;
}

.ul-list li:hover {
  background: #409eff;
  color: #ffffff;
}

li.none {
  text-align: center;
  color: #cccccc;
}

li.none:hover {
  background: none;
  color: #cccccc;
  cursor: auto;
}

.seach-input {
  height: 40px;
  padding: 5px 0;
}

.setheight {
  overflow: hidden;
  height: 300px;
}

input {
  color: #606266 !important;
  transition: border-color 0.2s cubic-bezier(0.645, 0.045, 0.355, 1);
}

input:hover {
  border-color: #c0c4cc;
}

input::-webkit-input-placeholder {
  color: #c3c6ce !important;
}
</style>