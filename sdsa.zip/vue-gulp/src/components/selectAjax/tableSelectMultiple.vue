<template>
	<div ref="selectWrap" class="select-wrap">
		<span :data-id="data.id" :title="data.title">{{data.title}}</span>
		<i :class="{'is-reverse': shown}" @click.stop="click" class="el-select__caret el-input__icon el-icon-arrow-up"></i>
		<transition name="fade">
			<div ref="dropdownWrap" v-show="shown" class="dropdown" :style="dropdownStyle" @click.stop="()=>{}"  :class="{up: isup}">
				<div class="popper__arrow"></div>
				<div class="select-content" >
					<div class="seach-input">
						<el-input size="mini" style="width:100%; padding: 0;line-height: 30px;" :placeholder="searchPlaceholder" v-model='searchParam' @keyup.enter.native="searchAjax" suffix-icon="el-icon-search" ></el-input>
					</div>
					<div v-loading="loading" style="padding: 0;display: block;">
						<ul  v-listloadmore="loadMore" style="width:380px" class="ul-list">
							<li class="none" v-if="isNone">{{$t('msg-no-data')}}</li>
							<li v-if="!isNone"  :data-id="data.id"  :data-title="data.title" >No Select Option</li>
							<li v-for="item in listData" :key="item.code" :data-id="item.code"  :data-title="item.value"  :data-type="types" :data-selected="item.selected" :class="item.selected?'selected':'no-selected'"  @click="select">
						    	{{(showItemCode ? '（' + item.code + '）' : '') + item.value}}
						   </li>
						</ul>
					</div>
				</div>
			</div>
		</transition>
	</div>
</template>

<script>
	import API from '@/api'
	import {tipSuccess, tipError, tipWarn,not} from '@/utils/index.js'
	import * as types from "@/store/mutation-types";
	import { mapGetters } from "vuex";
	import * as _ from "lodash";
	export default {
		name: 'select-ajax-table',
		 computed: {
         ...mapGetters({
        subTypes:types.GET_SUB_TYPES,
		  })
	    },
		data: function() {
			return {
				current:0,
				shown: false,
				searchParam:'',
				size: 10,
				page: 1,
				isup: false,
				more: false,
				loading: false,
				listData:[],
				chooseDate:[],
				dropdownStyle:{
					top: 0,
					left: 0
				},
				data:Object.assign({},this.defaultData)
			}
		},
		props: {
			action: Function,
			defaultData: {
				type: Object,
				default: function(){
					return {
						id: "",
						title:"默认值"
					}
				}
			},
			searchPlaceholder: {
				type: String,
				default: function(){
					return this.$t('button-search')
				}
			},
			types: {
				type: String,
				default: function(){
					return 'dafault';
				}
			},
			queryParam:{
				type:Object,
				default:function(){return {}}
			},
			showItemCode: {
				type: Boolean,
				default: function() {
					return true;
				}
			}
		},
		computed: {
			isNone: function(){
				return !this.listData.length
			}
		},
		mounted () {
			
			var that = this;
			window.onresize = function(){
				that.getPosition();
			}

			document.addEventListener("click",this.documentclick,false)
		},
		destroyed(){
			window.onresize=null;
			document.removeEventListener("click",this.documentclick,false)

		},
		methods: {
			documentclick(e){
			//	console.log(e.target,'document')
				this.shown = false;
				this.page = 1;
				this.searchParam = '';
				this.more = false;
			},
			click (e){
			//	console.log(e.target,'target')
				this.$emit('click',e);
				var that = this;
				this.shown = !this.shown;
				if(!!this.shown){
					this.getPosition();
					that.searchAjax().then(function(){
						that.getPosition();
					});
				}else{
					that.page = 1;
					that.searchParam = '';
					that.more = false;
				}
				
			},
			select (e){
				
				let {id,title}=e.target.dataset;

				this.listData=this.listData.map(v=>{
					if(v.code===id&&v.value===title){
						return {...v,selected:!v.selected}
					}
					return v
				})
			//	let chosen=this.listData.filter(v=>v.selected)
				//console.log(this.chooseDate);
				this.$emit('listSelectCallback', e,this.queryParam,e.target.dataset);
	    	},
	    	clearInput(e){
				this.data={...this.defaultData};
				this.shown=false;
				this.$emit('listSelectCallback', {
		    			type: this.types,
		    			id: -1,
						title: this.data.title
		    		});


				// console.log(this.defaultData)
	    		// if(!!this.data.id && this.data.id != ''){
	    		// 	this.data.id = '';
		    	// 	this.data.title = this.types == 'group' ? '组团合计': (this.types == 'department' ? '部门合计': (this.types == 'counter' ? '交易对手合计' :(this.types == 'subject' ? '科目' : '')));
		    	// 	this.shown = false;
		    	// 	this.$emit('listSelectCallback', {
		    	// 		type: this.types,
		    	// 		id: "",
				// 		title: this.data.title
		    	// 	});
	    		// }
			},
			chooseSelectedGroup(){
				if (this.queryParam.types==undefined||this.queryParam.types==null) return;
				if(JSON.stringify(this.queryParam.types)===JSON.stringify(['01']) || JSON.stringify(this.queryParam.types)===JSON.stringify(['03'])){
				 if(this.$root.$store.state.report.subject.leftList.length===0) return 
				 return this.$root.$store.state.report.subject.leftList;
				}else{
				if(this.$root.$store.state.report.subject.rightList.length===0) return 
				return this.$root.$store.state.report.subject.rightList
				}
			},
			cpCallback (dims, more){
				let lists=this.chooseSelectedGroup();
				this.listData =dims.map(v=>{
					let e=_.find(lists,(o)=>(o.code===v.code&&o.value===v.value));
					if(e){
						return {...v,selected:true}
					}else{
						return {...v,selected:false}
					}
				});

            	this.more =  more;
            	this.page++;
			},
			cpLoadingCallback (dims, more){
				var that = this;
				dims.forEach(function(data){
            		that.listData.push(data)
				});
				let lists=this.chooseSelectedGroup();
				that.listData=that.listData.map(v=>{
					let e=_.find(lists,(o)=>(o.code===v.code&&o.value===v.value));
					if(e){
						return {...v,selected:true}
					}else{
						return {...v,selected:false}
					}
				});
            	that.more =  more;
            	that.page++;
			},
			getPosition(){
				var a = this.$refs.selectWrap.getBoundingClientRect();
				var b = this.$refs.dropdownWrap.getBoundingClientRect();
				var winHeight;
				if (window.innerHeight){
					winHeight = window.innerHeight;
				}else if ((document.body) && (document.body.clientHeight)){
					winHeight = document.body.clientHeight;
				}
				if(winHeight - a.top - a.height >= b.height){
					this.dropdownStyle = {
						top: a.top + a.height + 10 + 'px',
						left: a.left + 'px'
					}
					this.isup = false;
				}else{
					this.dropdownStyle = {
						top: a.top - b.height - 10 + 'px',
						left: a.left + 'px'
					};
					this.isup = true;
				}

			},
	    	loadMore: async function() {
	    		if(this.loading || !this.more){
	    			return;
	    		}
	    		this.loading = true;
				try{
					var that = this;
					var params = {
						pageSize: that.size,
						pageNum: that.page,
						projectId: this.$root.$store.state.common.params.projectId,
						queryParam: that.searchParam,
						...this.queryParam

					}
					let {data:{data,msg,status}}= await that.action()(params);
	                if(status===0){
                		that.cpLoadingCallback(data.list, data.hasNextPage);
	                }
					that.loading = false;
				}catch(e){
		            throw new Error(e);
		        }
			},
			searchAjax: async function() {
				try{
					var that = this;
					that.page = 1;
					that.listData = [];
					if(that.searchParam.length>50){
					tipWarn.call(this.$store,'输入内容不能超过50字符！');
					return;
					}
					var params = {
						pageSize: that.size,
						pageNum: that.page,
						projectId: this.$root.$store.state.common.params.projectId,
						queryParam: that.searchParam,
						...this.queryParam,
						
					}

					this.loading = true;
					let {data:{data,msg,status}}= await that.action()(params);
	                if(status===0){
                		that.cpCallback(data.list, data.hasNextPage);
	                }
					that.loading = false;
				}catch(e){
		            console.warn(e)
		        }
			}
		}
	}
</script>

<style scoped>
	.select-wrap{
		position: relative;
	    padding-right: 28px;
	    padding-left: 0;
	    word-wrap: normal;
	    text-overflow: ellipsis;
	    display: inline-block;
	    vertical-align: middle;
	    width: calc(100% - 0px);
	    -webkit-box-sizing: border-box;
	    box-sizing: border-box;
	    white-space: nowrap;
	    word-break: normal;
	    line-height: 23px;
	    overflow: hidden;
	}
	.el-icon-arrow-up:before {
	    content: "\E60C";
	    color: #404040 !important;
	}
	.select-wrap>i {
		position: absolute;
		right: 4px;
		top: 1px;
		color: #c0c4cc;
	    font-size: 14px;
	    -webkit-transition: -webkit-transform .3s;
	    transition: -webkit-transform .3s;
	    transition: transform .3s;
	    transition: transform .3s, -webkit-transform .3s;
	    transition: transform .3s,-webkit-transform .3s;
	    -webkit-transform: rotateZ(180deg);
	    transform: rotateZ(180deg);
	    line-height: 16px;
	    cursor: pointer;
	}
	.select-wrap>i.is-reverse {
	    -webkit-transform: rotateZ(0);
	    transform: rotateZ(0);
	}
	.dropdown {
		padding: 0;
		position: fixed;
		overflow: initial;
		z-index: 1001;
		min-width: 200px;
		min-height: 100px;
		border-radius: 4px;
		background: #FFFFFF;
		border: 1px solid #e4e7ed;
		box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
	}
	.popper__arrow{
	    top: -6px;
	    left: 50%;
	    margin-right: 3px;
	    border-top-width: 0;
	    display: flex;
	    border-bottom-color: #ebeef5;
	}
	.up .popper__arrow::after {
	    top: auto;
	    bottom: -5px;
	    border-bottom-width: 0;
	    border-top-color: #fff;
	    border-top-width: 6px;
	}
	.popper__arrow::after {
		content: " ";
    	border-width: 6px;
    	position: absolute;
	    display: block;
	    width: 0;
	    height: 0;
	    border-color: transparent;
	    border-style: solid;
	    top: -5px;
	    left: 30px;
	    margin-left: -6px;
	    border-top-width: 0;
	    border-bottom-color: #fff;
	}
	.select-content{
		padding: 5px;
		display: block;
	}
	.ul-list {
		list-style: none;
		padding: 0;
		padding: 5px;
		margin: 0;
		max-height: 200px;
		overflow: auto;
		
	}
	.ul-list li{
		white-space: nowrap;
		overflow: hidden;
		height: 30px;
		line-height: 20px;
		cursor: pointer;
		padding: 5px;
		border-radius: 4px;
		transition: all .5s ease;
		font-weight: normal;
		text-overflow: ellipsis;
        max-width: 360px;
        white-space: nowrap;
		overflow: hidden;
		position:relative
	}
	.ul-list li:hover{
		background: #409eff;
		color: #FFFFFF;
	}
	.ul-list li.selected::after {
    position: absolute;
    right: 0px;
    font-family: element-icons;
    content: "\E611";
    font-size: 12px;
    font-weight: 700;
    -webkit-font-smoothing: antialiased;
	-moz-osx-font-smoothing: grayscale;
	color:#777
    }
	li.none{
		text-align: center;
		color: #CCCCCC;
	}
	li.none:hover{
		background: none;
		color: #CCCCCC;
		cursor: auto;
	}
	.el-loading-spinner{
		width: calc(100% - 20px);
	}
	.seach-input{
		height: 40px;
		padding: 5px 0;
		display: block;
	}
	.setheight{
		overflow: hidden;
		height: 300px;
	}
	.el-loading-spinner{
		width: calc(100% - 20px);
	}
</style>
