<template>
	<div  style="display:inline-block;vertical-align:middle">
		<div @click.stop="click" ref="selectWrap" class="timepicker-input el-date-editor el-range-editor el-input__inner el-date-editor--daterange el-range-editor--mini" style="float: right;">
			<i class="el-input__icon el-range__icon el-icon-date"></i>
			<input :placeholder="$t('label-start-time')" class="el-range-input" :value="defaultDate.bgnDate" readonly> 
			<span class="el-range-separator" style="width:20px">{{$t('label-to')}}</span>
			<input :placeholder="$t('label-end-time')" class="el-range-input" :value="defaultDate.endDate" readonly>
			<i class="el-input__icon el-range__close-icon"></i>
		</div>
		<transition name="fade">
			<div  v-show="shown" class="dropdown" v-loading="loading" ref="dropdownWrap" :class="{up: isup}" :style="dropdownStyle" @click.stop="()=>{}">
				<div class="popper__arrow"></div>
				<div class="none" v-if="isNone">{{$t('msg-no-data')}}</div>
				<div class="timepicker" v-if="!isNone">
					<div class="header">
						<i class="el-icon-caret-left" :class='{noclick: hearderData.left}' @click="leftClick(hearderData.left)"></i>
						{{hearderData.year}}{{$t('label-year')}}
						<i class="el-icon-caret-right" :class='{noclick: hearderData.right}' @click="rightClick(hearderData.right)"></i>
					</div>
					<div class="body">
						<ul>
							<li v-for="(item,index) in startData" :key="index" :class="{notActive: !item.isSelected, active: item.isActive}"  @click="liClick('bgn', item, startData,item.saleDtBgn)">{{item.saleDtBgn}}</li>
						</ul>
						<ul>							
							<li v-for="(item,index) in endData" :key="index" :class="{notActive: !item.isSelected, active: item.isActive}"  @click="liClick('end', item, endData,item.saleDtEnd)">{{item.saleDtEnd}}</li>
						</ul>
					</div>
				</div>
			</div>
		</transition>
	</div>
</template>

<script>
	import API from '@/api'
	export default {
		name: 'timepicker',
		data: () => {
			return {
				shown: false,
				isup: false,
				loading: false,
				timeData: [],
				index: 0,
				hearderData: {
					year: 2017,
					left: true,
					right: false
				},
				startData: [],
				endData: [],
				dropdownStyle:{
					top: 0,
					left: 0
				}
			}
		},
		props: {
			action: Function,
			defaultDate: {
				type: Object,
				default: function(){
					return {
						bgnDate: "",
						endDate: ""
					}
				}
			},
			startTimeFixed:{
				type:Boolean,
				default:false
			}

		},
		computed: {
			isNone: function(){
				return !this.timeData.length
			}
		},
		created () {
			this.searchAjax(false);
		},
		mounted () {
			document.addEventListener("click",this.documentclick,false)
		},
		destroyed(){
			document.removeEventListener("click",this.documentclick,false)
		},
		methods: {
			documentclick(){
				this.shown = false;
			},
			rightClick(state){
				if(state){
					return;
				}
				this.index--
				
				this.renderData();
			},
			leftClick(state){
				if(state){
					return;
				}
				this.index++
				this.renderData();
			},
			liClick(type, item, data,chosen){
				if(!item.isSelected){
					return;
				}
				var bgn, end, index;
				data.forEach(function(_data){
					if((type == 'bgn' && _data.saleDtBgn != item.saleDtBgn) || (type == 'end' && _data.saleDtEnd != item.saleDtEnd)){
						_data.isActive = false;
					}else{
						item.isActive = !item.isActive;
						if(type == 'bgn' && item.isActive){
							bgn = item;
						}else{
							end = item;
						}
					}
				})
				// console.log(data);
				if(type == 'bgn'){
					this.endData.forEach(function(_data){
						if(_data.saleDtBgn != item.saleDtBgn && index == undefined){
							_data.isSelected = false
						}else{
							_data.isSelected = true;
							index = 1;
						}
						if(_data.isActive){
							end = _data
						}
					})
				}else{
					this.startData.forEach(function(_data){
						if(_data.saleDtEnd != item.saleDtEnd && index == undefined){
							_data.isSelected = true
						}
						else if(_data.saleDtEnd == item.saleDtEnd && index == undefined){
							//先选择的结束时间，这个月的开始时间也能选择，后面的不可选
							_data.isSelected = true
							index = 1;
						}
						else{
							_data.isSelected = false;
							index = 1;
						}
						if(_data.isActive){
							bgn = _data
						}
					})
				}
				
				if(!!bgn && !!end){
					this.shown = false;
					this.defaultDate.bgnDate = bgn.saleDtBgn;
					this.defaultDate.endDate = end.saleDtEnd;

					this.$emit('selectCallback', {
		    			bgn: bgn,
						end: end
		    		});
				}
			},
			click (){
				var that = this;
				this.shown = !this.shown;
				that.getPosition();
				if(!!this.shown){
					that.searchAjax().then(function(){
						that.getPosition()
					});
				}
			},
			getPosition(){
				var a = this.$refs.selectWrap.getBoundingClientRect();
				var b = this.$refs.dropdownWrap.getBoundingClientRect();
				var winHeight;
				if (window.innerHeight){
					winHeight = window.innerHeight;
				}else if ((document.body) && (document.body.clientHeight)){
					winHeight = document.body.clientHeight;	
				}
				if(winHeight - a.top - a.height >= b.height){
					this.dropdownStyle = {
						top: a.top + a.height + 10 + 'px',
						left: a.left + 'px'
					}
					this.isup = false;
				}else{
					this.dropdownStyle = {
						top: a.top - b.height - 10 + 'px',
						left: a.left + 'px'
					};
					this.isup = true;
				}
			},
			renderData(){
				var that = this;
				if(!this.timeData.length){
					return;
				}
				//渲染表头
				var index = this.index;
				this.hearderData = {
					year: this.timeData[index].year,
					left: !(index == 0) ? true : false,
					right: !(index == this.timeData.length - 1) ? true : false
				}
				//渲染开始的日期
				this.startData = []
				this.timeData[index].reportDates.forEach(function(data,index){

					that.startData.push({
						acgMo: data.acgMo,
						acgYr: data.acgYr,
						isSelected: that.startTimeFixed?false:true,
						isActive: (that.startTimeFixed&&index===0)?true:false ,
						saleDtBgn: data.saleDtBgn,
						saleDtEnd: data.saleDtEnd
					})
				});
				//渲染结束的日期
				this.endData = []
				this.timeData[index].reportDates.forEach(function(data){
					that.endData.push({
						acgMo: data.acgMo,
						acgYr: data.acgYr,
						isSelected: true,
						isActive: false,
						saleDtBgn: data.saleDtBgn,
						saleDtEnd: data.saleDtEnd
					})
				});
				console.log(this.timeData);
			},
			searchAjax: async function(needRender = true) {
				try{
					var that = this;
					that.loading = true;
					var params = {
						projectId: this.$root.$store.state.common.params.projectId
					}
					this.loading = true;
					let {data:{data, msg, status}}= await that.action()(params);
	                if(status===0){
	                	this.timeData = data;
	                	if(needRender)
	                		that.renderData();
	                }
				}catch(e){
		            throw new Error(e);
		        }finally{
					this.loading = false;

				}
			}
		}
	}
</script>

<style scoped>
	.timepicker-input{
		cursor: pointer;
	}
	.timepicker-input input{
		cursor: pointer;
	}
	.dropdown {
		position: fixed;
		z-index: 1001;
		min-width: 200px;
		min-height: 100px;
		border-radius: 4px;
		background: #FFFFFF;
		border: 1px solid #e4e7ed;
		box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
	}
	.up .popper__arrow::after {
	    top: auto;
	    bottom: -5px;
	    border-bottom-width: 0;
	    border-top-color: #fff;
	    border-top-width: 6px;
	}
	.popper__arrow::after {
		content: " ";
    	border-width: 6px;
    	position: absolute;
	    display: block;
	    width: 0;
	    height: 0;
	    border-color: transparent;
	    border-style: solid;
	    top: -5px;
	    left: 30px;
	    margin-left: -6px;
	    border-top-width: 0;
	    border-bottom-color: #fff;
	}
	.timepicker .body{
		padding: 10px;
		display: flex;
		width: 300px;
		flex-direction: row;
		flex-wrap: nowrap;
		justify-content: space-between;
		align-items: flex-start
	}
	.timepicker ul{
		width: 270px;
		list-style: none;
		margin: 0;
		padding: 0;
		max-height: 250px;
		overflow: auto;
	}
	.timepicker ul li{
		line-height: 20px;
		white-space: nowrap;
		cursor: pointer;
		padding: 5px;
		border-radius: 4px;
	}
	.timepicker ul li:hover{
		background: #f7f7f7;
	}
	.timepicker ul li.active{
		background: #409eff;
		color: #FFFFFF;
	}

	.timepicker ul li.notActive.active{
		color:#fff
	}

	.timepicker ul li.notActive{
		cursor: not-allowed;
		color: #cbcad0;
	}
	.timepicker .header{
		height: 40px;
	    text-align: center;
	    position: relative;
	    line-height: 40px;
	    font-weight: bold;
	    font-size: 20px;
	}
	.timepicker .header i{
		cursor: pointer;
		position: absolute;
		top: 10px;
		color: #0091da;
	}
	.timepicker .header i.noclick{
		color: #ccc;
		cursor: auto;
	}
	.timepicker .header i.el-icon-caret-left{
		left: 60px;
	}
	.timepicker .header i.el-icon-caret-right{
		right: 60px;
	}
	.select-content{
		padding: 5px;
	}
	.none{
		text-align: center;
	    font-size: 16px;
	    line-height: 100px;
	    color: #ccc;
	}
</style>