<template>
<div class="hll-sub-header">
    <div class="centered">
    <i :class="current.icon"></i>
    <span>{{current.name}}</span>
    </div>

    <div  class="hll-right-header">
        <!-- <span>12353</span> -->
        <div class="centered">
            <span></span>
            <a href="#" @click="helpPopWin"><i class="fa fa fa-exclamation-circle icon-warning" /></a>
        </div>
    </div>

</div>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import * as types from "@/store/mutation-types";
export default {
  name: "common-sub-header",
  props: {
    icon: String,
    title: String,
    comment: String,
    handle: Function
  },
  methods: {
    ...mapActions({ helpPopWin: "helpPopWin" })
  },
  computed: {
    ...mapGetters({
      current: types.GET_CURRENT_ROUTE_NAME
    })
  }
};
</script>
<style scoped>
.hll-sub-header {
  height: 36px;
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  background: #f4f4f4;
  color: #666;
  font-size: 1.4rem;
}
.hll-sub-header i {
  font-size: 2.2rem;
}
.hll-right-header,
.centered {
  display: flex;
  align-items: center;
}
.hll-sub-header span {
  margin: 0 16px;
}
.icon-warning {
  color: #ffcc67;
  font-size: 1.2rem;
}
</style>
