<template>
<transition name="slide">
<div v-if="isVisible" class="skin">

    <p class="title">{{$t('style-setting')}}</p>

    <div class="line"/>

    <p class="theme">{{$t('theme-setting')}}<p/>

    <ul class="flex-r-centered skin-row1" @click="(e)=>pickColor(e)">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
    </ul>

    <ul class="flex-r-centered skin-row2" @click="pickColor">
        <li></li>
        <li></li>
        <li></li>
        <li></li>
    </ul>

    <div class="line"/>


    <p class="theme">{{$t('side-style')}}</p><p/>

    <ul class="flex-r-centered skin-row3" @click="pickSider">
        <li data-style="bg-hl-white">{{$t('color-white')}}</li>
        <li data-style="bg-hl-black">{{$t('color-black')}}</li>
        <li data-style="bg-hl-blue">{{$t('color-blue')}}</li>
    </ul>

    <p class="comment">{{$t("color-tips")}}</p>


</div>
</transition>


</template>
<script>
import { mapActions } from "vuex";
import * as types from "@/store/mutation-types";

export default {
  name: "skin",
  props: {
    isVisible: Boolean
  },
  methods:{
      ...mapActions({
          pickColor:"pickColor",
          pickSider:"pickSider"
      })
  }

};
</script>

<style scoped>
.skin {
  position: fixed;
  padding: 10px;
  top: 50px;
  right: 0;
  bottom: 0;
  width: 320px;
  background: #ffffff;
  box-shadow: 1px 0px 15px 0px #777474;
  z-index: 99999;
}

.slide-enter-active,
.slide-leave-active {
  transition: all 0.5s;
}
.slide-enter,
.slide-leave-to {
  opacity: 0;
  transform: translate(230px, 0);
}
.line {
  background: #999;
  height: 1px;
}
.skin-row1,
.skin-row2,
.skin-row3 {
  padding: 0;
  margin: 0;
  justify-content: space-between;
  list-style: none;
  margin-bottom: 16px;
}
.skin-row1 li,
.skin-row2 li,
.skin-row3 li {
  width: 60px;
  height: 30px;
  cursor: pointer;
  text-align: center;
  border-radius: 2px;
}
.skin-row3 li {
  width: 90px;
  line-height: 30px;
  font-size: 1.2rem;
}
.skin-row1 li:hover,
.skin-row2 li:hover {
  transform: scale(1.05);
  transition: all 0.2s;
}

.skin-row1 li:nth-child(1) {
  background: #00a3a1;
}

.skin-row1 li:nth-child(1):hover {
  box-shadow: 0 0 11px -1px #00a3a1;
}

.skin-row1 li:nth-child(2) {
  background: #0091da;
}

.skin-row1 li:nth-child(2):hover {
     box-shadow: 0 0 11px -1px #0091da;
}

.skin-row1 li:nth-child(3) {
  background: #da6c0a;
}

.skin-row1 li:nth-child(3):hover {
  box-shadow: 0 0 11px -1px #da6c0a;
}
.skin-row1 li:nth-child(4) {
  background: #ffcc66;
}
.skin-row1 li:nth-child(4):hover {
  box-shadow: 0 0 11px -1px #ffcc66;
}

.skin-row2 li:nth-child(1) {
  background: #a71d43;
}
.skin-row2 li:nth-child(1):hover {
  box-shadow: 0 0 11px -1px #a71d43;
}
.skin-row2 li:nth-child(2) {
  background: #00338d;
}
.skin-row2 li:nth-child(2):hover {
  box-shadow: 0 0 11px -1px #00338d;
}
.skin-row2 li:nth-child(3) {
  background: #e36877;
}
.skin-row2 li:nth-child(3):hover {
  box-shadow: 0 0 11px -1px #e36877;
}
.skin-row2 li:nth-child(4) {
  background: #9d9375;
}
.skin-row2 li:nth-child(4):hover {
  box-shadow: 0 0 11px -1px #9d9375;
}

.title {
  font-size: 1.6rem;
}
.theme {
  font-size: 1.4rem;
  font-weight: 600;
}

.skin-row3 li:nth-child(1) {
  border: 1px solid #ccc;
}

.skin-row3 li:nth-child(2) {
  border: 1px solid #000;
  color: #fff;
  background: #000;
}

.skin-row3 li:nth-child(3) {
  border: 1px solid #0091da;
  color: #fff;
  background: #0091da;
}
.comment {
  color: #999;
  font-size: 1.2rem;
}
</style>