<template>
<transition :duration="500" name="slide" >
<div class="site-sidebar-right" v-if="isShow" @click="helpPopWin">
	<a href="#"><i class="fa fa fa-exclamation-circle icon-warning" /></a>
	<span>帮助</span>
	<div class="line"/>
	<p>帮助标题</p>
	<p>帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	</p>
	<div class="line"/>
	<p>帮助标题</p>
	<p>帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	</p>
	<div class="line"/>
	<p>帮助标题</p>
	<p>帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容帮助内容
	</p>
</div>
</transition>
</template>

<script>
import {mapActions,mapGetters} from "vuex";
export default {
  name: "pop-up",
  props:{
	  isShow:Boolean
  },
  methods: {
      ...mapActions({helpPopWin:"helpPopWin"}),
  }
};
</script>
<style scoped>

.line{
    background: #999;
    height: 1px;
}
.site-sidebar-right{
	border: 10px solid;
	border-color: #F2F6FC;
	border-top-left-radius: 5px;
	border-bottom-left-radius: 5px;
	position: fixed;
	right:0;
	top:50px;
	bottom: 0px;
	width:320px;
	z-index: 999;
	overflow: auto;
	background-color: #ffffff;
	}

.site-sidebar-right:hover{
	box-shadow: 1px 0px 15px 0px #777474;
}

.slide-enter-active{
	transition:all 0.3s ease;
}

.slide-leave-active{
	transition:all 0.3s ease;
}

.slide-enter,.slide-leave-to{
 	transform: translateX(100%);
}

.icon-warning {
    color:#ffcc67;
    font-size: 2.2rem
}
</style>
