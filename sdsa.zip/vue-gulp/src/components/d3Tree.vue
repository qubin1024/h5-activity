<template>
  <div class="tree" id="tree" @dblclick.stop="()=>{}"></div>
</template>
<script>
import * as _ from "lodash";
let margin = [205, 120, 20, 105],
  width,
  height,
  i = 0,
  duration = 750,
  root,
  tree,
  diagonal,
  zoom,
  svg,
  showDept = 1;
//config expand  level by config the META_SHOW_DEPT option in /config/index.js
if (process.env.NODE_ENV === "production" && window.META_SHOW_DEPT) {
  showDept = +window.META_SHOW_DEPT;
}

export default {
  name: "d3-tree",
  data: function() {
    return {};
  },
  mounted: function() {
    (width = document.getElementById("tree").offsetWidth),
      (height = document.getElementById("tree").offsetHeight || 634);

    tree = d3.layout.tree().size([height, width]);
    diagonal = d3.svg.diagonal().projection(function(d) {
      return [d.y, d.x];
    });
    zoom = d3.behavior
      .zoom()
      .scaleExtent([0.1, 100])
      .translate([margin[3], margin[0]])
      .on("zoom", this.zoomed); //添加放大缩小事件
    svg = d3
      .select("body")
      .select("#tree")
      .append("svg")
      .call(zoom) //给svg绑定zoom事件
      .append("g")
      .call(zoom) //给g绑定zoom事件
      .append("g")
      .attr("transform", "translate(" + margin[3] + "," + margin[0] + ")");
  },
  watch: {
    data: function(v) {
      root = v;
      root.x0 = height / 2;
      root.y0 = 0;

      console.time("数据组合耗时");
      root = this.cols(root);
      console.timeEnd("数据组合耗时");

      this.update(root);
    },
    scaleY: function(v) {
      this.update(root);
    },
    scaleX: function(v) {
      this.update(root);
    }
  },
  methods: {
    collapse: function(d) {
      if (d.children) {
        d._children = d.children;
        d._children.forEach(this.collapse);
        d.children = null;
      }
    },
    resetPosition: function() {
      svg.attr(
        "transform",
        "translate(" + margin[3] + "," + margin[0] + ")" + "scale(1)"
      );

      zoom.translate([margin[3], margin[0]]).scale();
    },
    cols(v) {
      let obj = JSON.parse(JSON.stringify(v));
      let change = function(arr, dept = 1) {
        for (let i = 0; i < arr.length; i++) {
          let _dept = dept,
            children = arr[i].children;

          if (_dept < showDept) {
            arr[i]._children = null;
          } else {
            arr[i]._children = children;
            arr[i].children = null;
          }

          arr[i]._dept = dept;

          if (children && children.length > 0) {
            change(children, ++_dept);
          }
        }
      };

      change(obj.children);

      return obj;
    },
    zoomed: function() {
      svg.attr(
        "transform",
        "translate(" + zoom.translate() + ")" + "scale(" + zoom.scale() + ")"
      );
    },
    click: function(d) {
      if (d.children) {
        d._children = d.children;
        d.children = null;
      } else {
        d.children = d._children;
        d._children = null;
      }

      if (this.nodeClicked) this.nodeClicked(d);

      this.update(d);
    },
    update: function(source) {
      // Compute the new tree layout.
      var nodes = tree
          .separation(function(a, b) {
            return (a.parent == b.parent ? 1 : 2) * a.depth;
          })
          .nodes(root)
          .reverse(),
        links = tree.links(nodes);

      // Normalize for fixed-depth.
      nodes.forEach(d => {
        d.y = d.depth * 240;
        d.x *= this.scaleY * this.scaleY * 0.1875 + 0.1825;
      });
      console.log(nodes);

      // Update the nodes…
      var node = svg.selectAll("g.node").data(nodes, function(d) {
        return d.id || (d.id = ++i);
      });
      // Enter any new nodes at the parent's previous position.
      var nodeEnter = node
        .enter()
        .append("g")
        .attr("class", "node")
        .attr("transform", function(d) {
          return "translate(" + source.y0 + "," + source.x0 + ")";
        })
        .on("click", this.click);

      nodeEnter
        .append("circle")
        .attr("r", 1e-6)
        .style("fill", function(d) {
          return d.depth === 7
            ? "#fff"
            : d._children ? "lightsteelblue" : "#fff";
        });

      nodeEnter
        .append("text")
        .attr("x", function(d) {
          return d.children || d._children ? -10 : 10;
        })
        .attr("dy", ".35em")
        .attr("text-anchor", function(d) {
          return d.children || d._children ? "end" : "start";
        })
        .text(function(d) {
          return d.text;
        })
        .style("fill-opacity", 1e-6)
        .style("font-size", "12px");

      var nodeUpdate = node
        .transition()
        .duration(duration)
        .attr("transform", function(d) {
          return "translate(" + d.y + "," + d.x + ")";
        });

      nodeUpdate
        .select("circle")
        .attr("r", 4.5)
        .style("fill", function(d) {
          return d.depth === 7
            ? "#fff"
            : d._children ? "lightsteelblue" : "#fff";
        });

      nodeUpdate.select("text").style("fill-opacity", 1);

      var nodeExit = node
        .exit()
        .transition()
        .duration(duration)
        .attr("transform", function(d) {
          return "translate(" + source.y + "," + source.x + ")";
        })
        .remove();

      nodeExit.select("circle").attr("r", 1e-6);

      nodeExit.select("text").style("fill-opacity", 1e-6);

      var link = svg.selectAll("path.link").data(links, function(d) {
        return d.target.id;
      });

      link
        .enter()
        .insert("path", "g")
        .attr("class", "link")
        .attr("d", function(d) {
          var o = { x: source.x0, y: source.y0 };
          return diagonal({ source: o, target: o });
        });

      link
        .transition()
        .duration(duration)
        .attr("d", diagonal);

      link
        .exit()
        .transition()
        .duration(duration)
        .attr("d", function(d) {
          var o = { x: source.x, y: source.y };
          return diagonal({ source: o, target: o });
        })
        .remove();

      nodes.forEach(function(d) {
        d.x0 = d.x;
        d.y0 = d.y;
      });
    }
  },
  props: {
    data: Object,
    nodeClicked: Function,
    scaleY: Number,
    scaleX: Number
  }
};
</script>
<style>
.node {
  cursor: pointer;
}

.node circle {
  fill: #fff;
  stroke: steelblue;
  stroke-width: 1.5px;
}

.node text {
  font: 10px sans-serif;
}

.link {
  fill: none;
  stroke: #ccc;
  stroke-width: 1.5px;
}

.tree {
  width: 100%;
  height: 100%;
  margin: 0 auto;
  background: #e0e0e0;
}

.tree svg {
  width: 100%;
  height: 100%;
}
</style>