<template>
<el-dialog title="科目详细信息" :visible.sync="isShowSubDetail1" :modal-append-to-body="false" class="hll-dialog"
           @close="closeDetail()" width="60%">
    <el-table :data="subDetailList"  size="mini"  class="my-table"  v-loading="loading"
         v-loadmore="onLoadingMore" height="400"
         :header-cell-class-name="headerCellStyle"
        :cell-style="commonCellStyle" >
      
      <el-table-column v-for="headerItem in detailHeaderList" :key='headerItem.clmnCd' :prop='headerItem.clmnCd' :label='headerItem.fldNm' show-overflow-tooltip>
      </el-table-column>
      
    </el-table>
</el-dialog>
</template>
<script>
import { mapActions, mapGetters } from "vuex";
import SelectAjax from "@/components/selectAjax/index.vue";
import * as types from "@/store/mutation-types";
import API from "@/api";
export default {
  name: "show-subDetail",
  props: {
    isShowSubDetail: Boolean
  },
  mounted: function() {},
  computed: {
    ...mapGetters({
      loading: types.REPORT_TABLE_DATA_LOADING,
      detailHeaderList: types.REPORT_SUB_DETAIL_TABLE_HEADER_DATA,
      subDetailList: types.REPORT_SUB_DETAIL_TABLE_DATA,
      pagination: types.SUB_DETAIL_REPORT_TABLE_PAGINATION,
      hasMoreRecord: types.HAS_MORE_RECORD,
    }),
    isShowSubDetail1: {
      get: function() {
        return this.isShowSubDetail;
      },
      set: function(isShowSubDetail) {}
    }
  },
  methods: {
    ...mapActions({
      getJournalDetailTableHeader: "getJournalDetailTableHeader",
      showSubDetail: "showSubDetail"
    }),
    
    closeDetail: function() {
      this.$store.commit(types.RESET_CURRENT_SUB_CURRENT_DATA,{param:''}); //设置第一页
      this.$store.dispatch("closeDetail");
      
    },

     _rowStyle({ row, rowIndex }) {
      return {};
    },
     /**
     * 下拉加载更多
     */
    onLoadingMore: function() {
      this.$store.commit(types.ADD_CURRENT_SUB_PAGE_NUMBER);
      this.showSubDetail(null);
    },
    headerCellStyle: ({ row, rowIndex }) => "hll-header-cell",
    commonCellStyle: () => ({
      fontSize: "1.2rem",
      textAlign: "left",
      border: "0",
      padding: "8px 0"
    }),
    
  },
  components: {
    SelectAjax
  }
};
</script>
