<template>
<el-dialog title="添加" :visible.sync="isAddPopWinShow1" :modal-append-to-body="false" class="hll-dialog"
           @close="closeAddReportPopWin('form')" width="45%">
    <el-form :model="form" ref="form" :rules="rules">
        <el-form-item label="分录" :label-width="formLabelWidth">
            <el-input v-model="addReportForm.accountName" :disabled="true" size="mini"/>
        </el-form-item>
        <el-form-item label="本方" :label-width="formLabelWidth">
            <el-input v-model="addReportForm.corpNm" :disabled="true" size="mini"/>
        </el-form-item>
        <el-form-item label="对方" :label-width="formLabelWidth">
            <el-input v-model="addReportForm.cstNm" :disabled="true" size="mini"/>
        </el-form-item> 
         <el-form-item label="科目" :label-width="formLabelWidth">
            <select-ajax  
                        @listSelectCallback="onSelectChange"
                        placeholder="请选择科目" 
                        :defaultData="{id:form.sbjCd,title:form.sbjNm}"
                        :action="templateApi" 
                        :queryParam="{corpCode:addReportForm.corpCd,param:''}"
                        style="width:85%;margin:0 30px;height:45px;line-height:45px"
                        type="1">
          </select-ajax>
        </el-form-item> 
        <el-form-item label="抵消金额" :label-width="formLabelWidth" >
            <el-input v-model="form.amtEop" size="mini" type="number" ref="num"/>
        </el-form-item>
        <el-form-item label="备注说明" :label-width="formLabelWidth">
            <el-input v-model="form.remark" type="textarea" size="mini" ref="count" />

        </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
        <el-button @click="closeAddReportPopWin('form')" size="mini">取消</el-button>
        <el-button type="primary" size="mini" @click="submitForm('form')" :loading="isLoading">确定</el-button>
    </div>
</el-dialog>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import SelectAjax from "@/components/selectAjax/index";
import API from "@/api";
import * as _ from "lodash";
import * as types from "@/store/mutation-types";
import {tipSuccess, tipError, tipWarn} from '@/utils/index.js'
export default {
  name: "add-report",
  props: {
    isAddPopWinShow: Boolean
  },
  data() {
    return {
      formLabelWidth: "80px",
      inputMaxL:'2',
      number: '60',
      form: {
        amtEop: "",//抵消金额
        amtOfst: "",//抵消金额
        remark: "",//备注
        sbjCd: "",//科目的id
        sbjLvl: "",//科目的级别
        sbjNm: "",//科目的名字
        sbjTpCd: "",//未知参数
        sbjTpNm: ""//未知参数
      },
      rules: {
        // money:[{required: true, message: '', trigger: 'blur'}],
        //  comment:[{required: true, message: '', trigger: 'blur'}]
      },
      btnLoading:false
    };
  },
  watch: {
       form:{
                handler:function() {
                var _that = this;
                var _sum = 60; //字体限制为60个
                _that.number= _sum-_that.$refs.count.value.length;
                if(_that.number<=0){
                  tipWarn.call(this.$store,'备注信息超过最大限制！');
                  _that.form.remark=_that.$refs.count.value.substring(0,59);  
				          return ;
                }
              },
                deep:true
     }
  },
  computed: {
    ...mapGetters({
      addReportForm: types.GET_POST_FORM_PARAMS,
      isLoading:types.FORM_POST_LOADING
    }),
    isAddPopWinShow1: {
      get: function() {
        Object.keys(this.form).map((value)=>this.form[value]='')//清空表单
        return this.isAddPopWinShow;
      },
      set: function(isAddPopWinShow) {}
    }
  },
  methods: {
    onSelectChange: function(param) {
      let {id,title,level,balance}=param;
      this.form.sbjCd=id;
      this.form.sbjLvl=level||"1";
      this.form.sbjNm=title;
    },

    closeAddReportPopWin: function(formName) {
      this.$refs[formName].resetFields(); //这一行没有用!
      Object.keys(this.form).map((value)=>this.form[value]='')//清空表单
      this.$store.dispatch("closeAddReportPopWin");
    },

    submitForm: function(formName) {
      if(this.form.sbjCd=='' || this.form.sbjLvl==''|| this.form.sbjNm==''){
	          tipWarn.call(this.$store,'请选择科目！');
				    return ;
      }
      if(this.form.amtEop == '' || this.form.amtEop== null || this.form.amtEop== undefined ){
	    			tipWarn.call(this.$store,'请填写手工抵消金额！');
				    return ;
      }
      var pattern_amtEop = /^-?[0-9]*(0?\.\d{1,2})?$/;
      if(!pattern_amtEop.test(this.form.amtEop)) {
            tipWarn.call(this.$store,'输入的抵消金额格式不正确！');
            return ;
      }
      if(this.addReportForm.diffMoney-this.form.amtEop<0)
      {
           tipWarn.call(this.$store,'手工抵消金额不能大于差异金额');
				    return ;
      }
      if(parseFloat(this.form.amtEop) <=0) {
				  tipWarn.call(this.$store,'手工抵消金额必须大于0');
				  return;
			}
      if(this.form.remark == '' || this.form.remark== null || this.form.remark== undefined || this.form.remark.split(" ").join("").length==0 ){
          
          tipWarn.call(this.$store,'请填写备注！');
				  return ;
      }
      this.form.remark = this.form.remark.replace(/_#_@/g, '\n');//IE7-8
      this.$refs[formName].validate(vaild => {

        let commonParam=this.$store.state.common.params;
        //手动拼接form参数,store中的参数,和rootStore中的参数
        let params=Object.assign({},this.form,this.addReportForm,commonParam,{amtOfst:this.form.amtEop});
          this.$store.dispatch("addRecordList",params).then(this.closeAddReportPopWin.bind(this,'form'));

      });
    },
    templateApi: () => {
      return API.common.getCourseInfo;
    },
    },
  components: {
    SelectAjax
  }
};
</script>

<style >
.hll-dialog .el-dialog {
  width: 50%;
}
.hll-dialog .el-dialog__header {
  background-color: #337ab7;
  border-top-left-radius: 5px;
  border-top-right-radius: 5px;
  border-color: #337ab7;
}

.hll-dialog .el-dialog__title {
  color: #fff;
  font-size: 12px;
}

.hll-dialog .el-input__inner {
  width: 85%;
  height: 30px;
  margin-left: 30px;
}

.hll-dialog .el-form-item__label {
  font-size: 12px;
}

.hll-dialog .el-form-item {
  margin-bottom: 5px;
}

.hll-dialog .el-textarea__inner {
  width: 85%;
  margin-left: 30px;
}
</style>
<style scoped>
 .select-wrap >>> .close {
   top: 9px;
 }
 .hll-dialog >>> .seach-input .el-input__inner {
  width: 100%;
  height: 30px;
  margin-left: 0px;
}
</style>

