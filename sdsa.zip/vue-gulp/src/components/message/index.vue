<template>
  <div :data-id="hh" style="width:0;height:100%">
    {{hh}}
  </div>
</template>

<script>
import * as types from "@/store/mutation-types";
import { mapGetters } from "vuex";
export default {
  name: "message-box",
  computed: {
    hh:function(){
        let {type,message,count}=this.$store.state.messageBox;
        if(count===0) return count
        this.$message({
          message,
          type
        });
        return count
    }
  },
};
</script>