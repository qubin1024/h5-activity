import request from '../request';
import requestUrl from '../requestUrl';
import requestParam from '../requestParam';

export function getFirstRisksByTopic(params) {
  return request({
    url: requestUrl('kfs-server/detail/getFirstRiskByTopic'),
    method: 'post',
    data: requestParam(params)
  });
}

// todo(ccliu): 如何注入全局定义的对象
export function getRiskInfoByRiskId(params) {
  return request({
    url: requestUrl('kfs-server/detail/getRiskInfoByRiskId'),
    method: 'post',
    data: requestParam(params)
  });
}

export function getRadarChartByFirstRisk(params) {
  return request({
    url: requestUrl('kfs-server/detail/getRadarChartByFirstRiskId'),
    method: 'post',
    data: requestParam(params)
  });
}

export function getThreeLevelRiskInfoById(params) {
  return request({
    url: requestUrl('kfs-server/detail/getThirdRiskInfoById'),
    method: 'post',
    data: requestParam(params)
  });
}

export function getThreeLevelRiskDataList(params) {
  return request({
    url: requestUrl('kfs-server/detail/getDataByThirdRiskId'),
    method: 'post',
    data: requestParam(params)
  });
}

export function getTableauFrames(params) {
  return request({
    url: requestUrl('kfs-server/tableau/getTableauTrustedUrl'),
    method: 'post',
    data: requestParam(params)
  });
}
