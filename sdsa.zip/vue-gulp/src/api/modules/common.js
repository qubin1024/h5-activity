import request from '../request'
import requestUrl from '../requestUrl'
import requestParam from '../requestParam'

// // 获取验证码
// export function captcha (uuid) {
//   return requestUrl(`/captcha.jpg?uuid=${uuid}`)
// }
// export function checkSession (header) {
//   return request({
//     url: requestUrl('userManager/checkSession'),
//     method: 'post',
//     header:{
//       ...header
//     },
//     data:requestParam({
//       d:new Date().getTime()
//     })
//   })
// }
// 登录
export function login(params) {
  return request({
    url: requestUrl('auth-server/authserver/checkLogin'),
    method: 'post',
    data: requestParam(params)
  })
}


export function sign(params) {
  return request({
    url: requestUrl('/auth-server/authserver/out?accountName=' + params.accountName + '&t=' + new Date().getTime()),
    method: 'get',
    data: requestParam(params)
  })
}

// 登录
export function getProjectList(params) {
  return request({
    url: requestUrl('userManager/getProjectList'),
    method: 'post',
    data: requestParam(params)
  })
}

export function getAD(params) {
  return request({
    url: requestUrl('getAD'),
    method: 'post',
    data: requestParam(params)
  })
}

export function getViewDictListByCode(params) {
  return request({
    url: requestUrl('base-server/stmDictData/accesstoken/getViewDictListByCode'),
    method: 'post',
    data: requestParam(params)
  })
}

export function getAppByUserId() {
  return request({
    url: requestUrl('user-server/userserver/menuFunctionInfo/accesstoken/getAppByUserId?t=' + new Date().getTime()),
    method: 'get',
    data: requestParam()
  })
}

export function updateUserLanguage(params) {
  return request({
    url: requestUrl('user-server/userserver/userInfo/accesstoken/updateUserLanguage'),
    method: 'post',
    data: requestParam(params)
  })
}

export function changePassword(params) {
  return request({
    url: requestUrl('user-server/userserver/userInfo/accesstoken/updatePwd'),
    method: 'post',
    data: requestParam(params)
  })
}

export function getSalt(params) {
  return request({
    url: requestUrl('user-server/userserver/userInfo/accesstoken/getUserSalt?kknm=' + params.kknm + '&t=' + new Date().getTime()),
    method: 'get'
  })
}

export function encryptAes(params) {
  return request({
    url: requestUrl('base-server/baseserver/projectInfo/accesstoken/encryptAes'),
    method: 'post',
    data: requestParam(params)
  })
}

export function encryptAesList(params) {
  return request({
    url: requestUrl('base-server/baseserver/projectInfo/accesstoken/encryptAesList'),
    method: 'post',
    data: params
  })
}

export function decryptAes(params) {
  return request({
    url: requestUrl('base-server/baseserver/projectInfo/accesstoken/decryptAes'),
    method: 'post',
    data: requestParam(params)
  })
}
