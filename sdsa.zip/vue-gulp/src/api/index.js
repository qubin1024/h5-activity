import * as common from './modules/common'
import kfs from '@/systems/KFS/api/index'
import modelmgr from '@/systems/modelmgr/api/index'
import dataload from '@/systems/dataLoad/api/index'
import * as risk from './modules/riskDetail';
export default {
  common,     // 公共
  risk,
  kfs,
  modelmgr,
  dataload
}
