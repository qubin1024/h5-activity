/**
 * 请求地址统一处理／组装
 * @param {*} actionName action方法名称
 */
export default function (actionName) {
  // 非生产环境 && 开启代理, 接口前缀统一使用[/proxyApi/]前缀做代理拦截!
  if (window.NODE_ENV == 'pro') {
    return '/pro/' + actionName
  } else if (window.NODE_ENV == 'test') {
    return '/test/' + actionName
  } else {
    return '/dev/' + actionName
  }
  //return (process.env.NODE_ENV !== 'production' && process.env.OPEN_PROXY ? '/proxyApi/' : 'proxyApi/') + actionName
  //return (process.env.NODE_ENV !== 'production' && process.env.OPEN_PROXY ? '/proxyApi1/' : "http://127.0.0.1:9999/proxyApi2/") + actionName

}
