import Vue from 'vue';
import Vuex from 'vuex';
import * as getters from './getters';
import mutations from './mutations';
import * as actions from './actions';
import storePersistence from './store-persistence-plugin';
import autoI18n from './store-auto-i18n-pluign';

import i18n from './modules/i18n';
import common from './modules/common';
import kfs from '@/systems/kfs/store/index';

Vue.use(Vuex);
const state = {};

export default new Vuex.Store({
  state,
  getters,
  mutations,
  actions,
  modules: { i18n, common, kfs },
  plugins: [storePersistence, autoI18n],
  strict: process.env.NODE_ENV !== 'production'
});
