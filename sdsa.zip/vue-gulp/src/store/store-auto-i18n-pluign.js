import Vue from "vue";

import { len } from "@/locale/en";
import { lcn } from "@/locale/cn";

const MODULE_NAME = "i18n";

const autoI18n = store => {
  var translate = function(param) {
    let i18Module = store.state[MODULE_NAME]["locale"];
    return i18Module === "zh_CN" ? lcn[param] : len[param];
  };
  Vue.prototype.$t = translate;
};

export default autoI18n;
