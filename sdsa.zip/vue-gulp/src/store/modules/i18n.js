import enLocale from "element-ui/lib/locale/lang/en";
import zhLocale from "element-ui/lib/locale/lang/zh-CN";

import locale from "element-ui/lib/locale";
const state = {
  locale: "zh_CN",
  translation: null
};

const getters = {
  getLanguage: ({ locale: lang }) => {
    document.documentElement.setAttribute('lang', lang)
    switch (lang) {
      case "en_US":
        locale.use(enLocale);
        break;

      case "zh_CN":
        locale.use(zhLocale);
        break;

      default:
        locale.use(zhLocale);
    }

    return lang;
  }
};

const mutations = {
  setLocale: (state, payLoad) => {
    payLoad = payLoad == 'zh_cn' ? 'zh_CN' : 'en_US'
    state.locale = payLoad;
  }
};

const actions = {
  setLanguage: ({ commit }, param) => commit("setLocale", param)
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
};
