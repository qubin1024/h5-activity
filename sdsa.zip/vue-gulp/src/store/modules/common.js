import API from "@/api/index";
const state = {
  userName: '',
  token: '',
  login: false,
  menuList: [],
  list: {
    _mainList: []
  },
  validaityDate: null,
  btnPermissionsArr: [],
  project: {
    projectId: '',
    projectName: 'null',
    topic: {
      topicCode: '',
      topicName: 'null'
    },
    topicDataList: []
  },
  projectList: []
};

const getters = {
  getUserName: ({ userName }) => userName,
  getToken: ({ token }) => token,
  checkLogin: ({ login }) => login,
  menuList: ({ menuList }) => menuList,
  list: ({ list }) => list,
  getValidaityDate: ({ validaityDate }) => validaityDate,
  getproject: ({ project }) => project,
  getprojectList: ({ projectList }) => projectList
};

const mutations = {
  setBtnPermissionsArr: (state, payLoad) => {
    state.btnPermissionsArr = payLoad;
  },
  setUserName: (state, payLoad) => {
    state.userName = payLoad;
  },
  setToken: (state, payLoad) => {
    state.token = payLoad;
  },
  setLogin: (state, payLoad) => {
    state.login = payLoad;
  },
  setMenuList: (state, payLoad) => {
    state.menuList = state.menuList.concat(payLoad);
  },
  setValidaityDate: (state, payLoad) => {
    state.validaityDate = payLoad;
  },
  setMainList: (state, payLoad) => {
    state.list._mainList = payLoad;
  },
  setKeyMainList: (state, { key, data }) => {
    state.list[key] = data;
  },
  setProject: (state, payLoad) => {
    state.project = payLoad;
    state.project.topic = state.project.topicDataList[0];
    // }
  },
  setTopic: (state, payLoad) => {
    state.project.topic = payLoad;
  },
  setProjectList: (state, payLoad) => {
    if (payLoad.length) {
      state.projectList = payLoad;
      state.project = payLoad[0];
      state.project.topic = state.project.topicDataList[0];
    } else {
      state.project = {
        projectId: '',
        projectName: 'null',
        topic: {
          topicCode: '',
          topicName: 'null'
        },
        topicDataList: []
      };
      state.projectList = []
    }
  }
};

const actions = {
  getInitdata: async ({ commit, state, rootState }, param) => {
    let { data: res } = await API.kfs.common.getProjectTopicDTOByUserId(param);
    commit('setProjectList', res.data);
    return res;
  }
};

export default {
  namespaced: true,
  state,
  getters,
  actions,
  mutations
};
