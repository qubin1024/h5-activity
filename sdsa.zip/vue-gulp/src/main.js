import Vue from 'vue';
import App from '@/App';
import router from '@/router';
import store from '@/store';
import "@/element-ui";
import "@/assets/iconfont/iconfont.css";
import "@/assets/fonts/kfs/style.css";
import '@/assets/scss/index.scss';
import '@/utils/regConfig.js';
import '@/utils/btnPermissions.js';
Vue.config.productionTip = false;

new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
});
