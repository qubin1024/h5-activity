<template>
	<div class="login-content" style="height: 100%;">
		<header>
	        <div class="bg">
	        </div>
			<div class="container" :class="{'form-success': isSuccess, 'form-error': isError}">
				<img src="../../assets/img/u30.png" width="150px"  />
				<h1>{{title}}</h1>
				<div class="form">
					<input type="text" :placeholder="$t('userName')" v-model.trim="dataForm.kamayhm" id="username-input" >
					<input type="password" :placeholder="$t('password')" onpaste = "return false" v-model.trim="dataForm.kamamm" @keyup.enter='login' id="password-input">
					<div class="error-tip">{{errorMessage}}</div>
					<button @click='debounceLogin'   v-focus id="login"><i class="el-icon-loading" style="margin: 0px 5px;" v-show="loading"></i>{{$t('signin')}}</button>
				</div>
			</div>
	    </header>
	</div>
</template>

<script>
import Vue from "vue";
import API from "@/api";
import * as _ from "lodash";
import { mapGetters, mapMutations, mapActions } from "vuex";
import Dotline from "@/components/jquery/constellation.js";
import * as types from "@/store/mutation-types";
import {
  tipSuccess,
  tipError,
  tipWarn,
  generateSHA,
  checkError
} from "@/utils";
import store from "@/store";
import { sha256 } from "js-sha256";
export default {
  data: function() {
    return {
      dataForm: {
        kamayhm: "",
        kamamm: ""
      },
      loading: false,
      isSuccess: false,
      isError: false,
      errorMessage: "",
      height: "500px",
      title: "KAFS反舞弊系统"
    };
  },
  created() {},
  directives: {
    focus: {
      inserted: function(el) {
        el.focus();
      }
    }
  },
  mounted() {
    var that = this;
  },
  destroyed() {
    window.onresize = null;
  },
  computed: {
    ...mapGetters("common", {
      userName: "getUserName"
    })
  },
  methods: {
    ...mapMutations("common", {
      setUserName: "setUserName",
      setToken: "setToken",
      setLogin: "setLogin",
      setMenuList: "setMenuList",
      setMainList: "setMainList",
      setKfsList: "setKfsList",
      setKeyMainList: "setKeyMainList",
      setValidaityDate: "setValidaityDate",
      setBtnPermissionsArr: "setBtnPermissionsArr"
    }),
    ...mapMutations("i18n", {
      setLocale: "setLocale"
    }),
    ...mapActions("common", {
      getInitdata: "getInitdata"
    }),
    debounceLogin: _.debounce(
      function() {
        this.login();
      },
      500,
      { leading: true }
    ),
    async getAppByUserId() {
      let { data: res } = await API.common.getAppByUserId();
      await this.getInitdata({
        appType: "kfs"
      });
      checkError(res, res => {
        this.setMainList(res.data);
        let menuList = [];
        res.data.forEach(async item => {
          menuList.push(item.dictCode);
          await this.queryMenuList(item.dictCode);
        });
        this.setMenuList(menuList);
      });
    },
    async queryMenuList(app) {
      let { data: res } = await API.dataload.common.getMgrMenuList({
        appType: app
      });
      checkError(res, res => {
        this.setKeyMainList({ key: app, data: res.data });
        let menuList = [];
        res.data.forEach(item => {
          menuList.push(item.path);
        });
        this.setMenuList(menuList);
      });
    },
    async login() {
      try {
        this.loading = true;

        if (!this.dataForm.kamayhm || !this.dataForm.kamamm)
          throw new Error(Vue.prototype.$t("account&passwordError"));
        let { data: saltRes } = await API.common.getSalt({
          kknm: this.dataForm.kamayhm
        });

        if (saltRes.code != 200) {
          throw new Error(saltRes.msg);
        }

        let params = Object.assign({}, this.dataForm, {
          kamamm: sha256(this.dataForm.kamamm + saltRes.data)
        });

        let { data: res } = await API.common.login(params);

        if (res.code != 200) {
          throw new Error(res.msg);
        }
        this.setLocale(res.data.language);
        this.setToken(res.data.token);
        this.setBtnPermissionsArr(res.data.functionCodeList);
        this.setLogin(true);
        this.setMenuList(["projectList"]);
        this.setUserName(this.dataForm.kamayhm);

        await this.getAppByUserId();

        //获取当前时间
        var date = new Date();
        var expires = 6;
        //将date设置为30分钟前台登陆将失效，请重新登陆
        date.setTime(date.getTime() + expires * 60 * 60 * 1000);
        //将userId和userName两个cookie设置为10天后过期
        document.cookie = "login=true; expires=" + date.toGMTString();
        this.setValidaityDate(res.data.validaityDate);
        this.$router.replace({ path: "/kfs/kfsHome" });
      } catch (e) {
        this.isError = true;
        this.errorMessage = e.message;
      } finally {
        this.loading = false;
      }
    }
  }
};
</script>

<style scoped>
.login-content {
  height: 1000px;
  font-size: 1em;
  line-height: 1.4;
}
.login-content {
  overflow-x: hidden;
}
* {
  margin: 0;
  padding: 0;
}

/*星座特效*/
#display {
  z-index: 0;
  display: block;
  cursor: default;
  position: absolute;
}
#blachole {
  position: fixed;
  top: 60px;
  right: 60px;
  width: 120px;
  height: 120px;
}
canvas {
  width: 100%;
  height: 100%;
}

/*第一屏*/
header {
  position: relative;
  color: white;
  height: 100%;
  min-height: 500px;
}

header .bg {
  height: 100%;
  width: 100%;
  background: url("../../assets/img/logobj.jpg") center no-repeat;
  background-size: cover;
}
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  font-weight: 300;
}
.container {
  position: fixed;
  top: 50%;
  left: 50%;
  width: 500px;
  max-width: 600px;
  margin-top: -240px;
  margin-left: -250px;
  padding: 50px 0;
  height: 400px;
  text-align: center;
  background: transparent;
}
.container h1 {
  font-size: 26px;
  -webkit-transition-duration: 1s;
  transition-duration: 1s;
  -webkit-transition-timing-function: ease-in-put;
  transition-timing-function: ease-in-put;
  font-weight: 200;
  line-height: 1;
  margin-top: 20px;
  font-weight: 500;
}
.form {
  padding: 20px 0;
  position: relative;
  z-index: 2;
}
.form input {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  outline: 0;
  border: 1px solid rgba(255, 255, 255, 0.4);
  background-color: rgba(255, 255, 255, 0.2);
  width: 350px;
  border-radius: 3px;
  padding: 10px 15px;
  margin: 0 auto 10px auto;
  display: block;
  text-align: center;
  font-size: 18px;
  color: white;
  -webkit-transition-duration: 0.25s;
  transition-duration: 0.25s;
  font-weight: 300;
}
::-webkit-input-placeholder {
  /* WebKit browsers */
  color: #ffffff;
}
:-moz-placeholder {
  /* Mozilla Firefox 4 to 18 */
  color: #ffffff;
}
::-moz-placeholder {
  /* Mozilla Firefox 19+ */
  color: #ffffff;
}
:-ms-input-placeholder {
  /* Internet Explorer 10+ */
  color: #ffffff;
}
.form input:hover {
  background-color: rgba(255, 255, 255, 0.4);
}
.form button:hover {
  background-color: #0185c7;
}
.form button {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  outline: 0;
  background-color: #0091da;
  border: 0;
  padding: 10px 15px;
  color: #fff;
  border-radius: 3px;
  width: 350px;
  cursor: pointer;
  font-size: 18px;
  -webkit-transition-duration: 0.25s;
  transition-duration: 0.25s;
}
.form input:focus {
  background-color: white;
  width: 370px;
  color: #666666;
}
.form-error .error-tip {
  display: block;
}
.error-tip {
  display: none;
  font-size: 12px;
  line-height: 1;
  margin-bottom: 10px;
}
.form-success.container h1 {
  -webkit-transform: translateY(85px);
  -ms-transform: translateY(85px);
  transform: translateY(85px);
}
.form-success.container img {
  -webkit-transform: translateY(85px);
  -ms-transform: translateY(85px);
  transform: translateY(85px);
}
.form-success.container .form {
  display: none;
}
botton {
  -webkit-appearance: none;
  -moz-appearance: none;
  appearance: none;
  outline: 0;
  background-color: #0091da;
  border: 0;
  padding: 10px 15px;
  color: #fff;
  border-radius: 3px;
  width: 350px;
  cursor: pointer;
  font-size: 18px;
  -webkit-transition-duration: 0.25s;
  transition-duration: 0.25s;
}
</style>
