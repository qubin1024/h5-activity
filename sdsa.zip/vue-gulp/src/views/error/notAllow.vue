<template>
    <div class="container">
        <p>
            this application is only capable for ie  
        </p>
    </div>
</template>
<script>
export default{
    name:'notAllowed',
    data:function(){
        return {
            time:3
        }
    },
    mounted(){
    },
    watch:{
        time:function(v){
        }
    }
}
</script>
<style scoped>
.container{
    display: flex;
    justify-content:center;
    align-items: center;
    background: #333
}
.container>p{
    display: inline-block;
    width: 880px;
    color: #eee;
    font-size: 32px;
    text-transform: uppercase;
    font-weight: bold;
    font-style: italic;
    text-align: center;
    text-shadow:0 0 10px #fff
}
</style>