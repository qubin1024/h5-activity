<template>
  <div class="container">
    <div class="head-bar">
      <img src="../../assets/img/kpmgLogo.png" width="100px" height="40px" />
      <span>Application List{{$t('manager-platform')}}</span>
      <el-dropdown style="float: right;" :hide-on-click="false">
      <span class="el-dropdown-link"  style="margin: 0;">
        <span id="username-text"><i class="fa fa-user" aria-hidden="true"></i> {{userName}}</span>
      </span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item  @click.native="signIn" ><i class="fa fa-sign-in" style="margin: 0 10px;" aria-hidden="true"></i>{{$t('signout')}}</el-dropdown-item>
        <el-dropdown-item @click.native="changeLang"><i class="fa fa-language" style="margin: 0 10px;" aria-hidden="true"></i>{{$t('language')}}({{langText}}）</el-dropdown-item>
        <el-dropdown-item @click.native="updatePassword"><i class="fa fa-pencil-square-o" style="margin: 0 10px;" aria-hidden="true"></i>{{$t('change-password')}}</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
    </div>
    <div class="projectList" id="application-wrap">
      <div class="project" :style="item.style" v-for="item in lists" :key="item.dictCode" @click="link(item.dictCode)">
        {{item.dictName}}
      </div>
    </div>
    <el-dialog
        :title="$t('change-password')"
        v-loading="loading"
        v-if="centerDialogVisible"
        :close-on-click-modal='false'
        :visible="true"
        width="400px"
        @close="centerDialogVisible = false"
        center>
        <el-form ref="form" :model="form"  :rules="rules" label-width="100px">
          <el-row :gutter="20">
            <el-col :span="24">
                <div class="grid-content bg-purple">
                    <el-form-item :label="$t('accountName')" prop="accountName">
                        <el-input size="mini" v-model="form.accountName" disabled></el-input>
                    </el-form-item>
                    <el-form-item :label="$t('oldPassword')" prop="oldkamamm">
                        <el-input size="mini" type="password" v-model="form.oldkamamm" ></el-input>
                    </el-form-item>
                    <el-form-item :label="$t('newPassword')" prop="newkamamm">
                        <el-input size="mini" type="password" v-model="form.newkamamm" ></el-input>
                    </el-form-item>
                </div>
            </el-col>
        </el-row>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="centerDialogVisible = false">{{$t('cancel')}}</el-button>
        <el-button type="primary" @click="sure">{{$t('sure')}}</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import Vue from "vue";
import API from "@/api";
import { checkError, getUUID, dateFormat } from "@/utils/index.js";
import { mapGetters, mapMutations } from "vuex";
import { sha256 } from "js-sha256";
import store from "@/store";
let colors = ["#ffca00", "#00daff", "#90f355", "#f5900f"];
export default {
  data() {
    return {
      loading: false,
      centerDialogVisible: false,
      form: {
        accountName: "",
        oldkamamm: "",
        newkamamm: ""
      },
      rules: {
        accountName: [
          {
            required: true,
            message: Vue.prototype.$t("must_fill"),
            trigger: "blur"
          },
          { pattern: /^[A-Za-z0-9_]+$/, message: Vue.prototype.$t("msg-reg3") },
          { max: 20, message: Vue.prototype.$t("msg-maxLength20") }
        ],
        oldkamamm: [
          {
            required: true,
            message: Vue.prototype.$t("must_fill"),
            trigger: "blur"
          },
          {
            pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[`~!@#$%^&*()_\-+=<>?:"{}|,.\/;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”【】、；‘’，。、])[A-Za-z\d`~!@#$%^&*()_\-+=<>?:"{}|,.\/;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”【】、；‘’，。、]{8,16}$/,
            message: Vue.prototype.$t("msg-reg2"),
            trigger: "blur"
          }
        ],
        newkamamm: [
          {
            required: true,
            message: Vue.prototype.$t("must_fill"),
            trigger: "blur"
          },
          {
            pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[`~!@#$%^&*()_\-+=<>?:"{}|,.\/;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”【】、；‘’，。、])[A-Za-z\d`~!@#$%^&*()_\-+=<>?:"{}|,.\/;'\\[\]·~！@#￥%……&*（）——\-+={}|《》？：“”【】、；‘’，。、]{8,16}$/,
            message: Vue.prototype.$t("msg-reg2"),
            trigger: "blur"
          }
        ]
      },
      options: [
        {
          label: Vue.prototype.$t("lang-ch"),
          value: "zh_CN"
        },
        {
          label: Vue.prototype.$t("lang-es"),
          value: "en_US"
        }
      ]
    };
  },
  mounted() {
    let validaityDate = this.getValidaityDate;
    let date = new Date();
    if (
      typeof validaityDate === "number" &&
      parseFloat((validaityDate - date.getTime()) / 1000 / 60 / 60 / 24) <= 5
    ) {
      const h = this.$createElement;
      this.$notify({
        title: "密码提示",
        type: "warning",
        position: "bottom-right",
        message: h("i", { style: "color: teal" }, [
          h("span", {}, "您的密码将于"),
          h(
            "span",
            { style: "color: red;" },
            dateFormat(new Date(validaityDate))
          ),
          h("span", {}, "后过期，请重置密码！")
        ])
      });
    }
  },
  computed: {
    ...mapGetters("common", {
      userName: "getUserName",
      getValidaityDate: "getValidaityDate",
      list: "list"
    }),
    ...mapGetters("i18n", {
      lang: "getLanguage"
    }),
    langText() {
      let langText;
      if (this.lang == "zh_CN") {
        langText = Vue.prototype.$t("lang-zh");
      } else {
        langText = Vue.prototype.$t("lang-es");
      }
      return langText;
    },
    lists() {
      let arr = [];
      this.list._mainList.forEach((item, index) => {
        arr.push(
          Object.assign({}, item, {
            style: {
              background: !!colors[index] ? colors[index] : colors[0]
            }
          })
        );
      });
      return arr;
    }
  },
  methods: {
    ...mapMutations("i18n", {
      setLang: "setLocale"
    }),
    ...mapMutations("common", {
      setUserName: "setUserName",
      setToken: "setToken",
      setLogin: "setLogin",
      setMenuList: "setMenuList",
      setBtnPermissionsArr: "setBtnPermissionsArr"
    }),
    langChange(val) {
      this.setLang(val);
    },
    sure() {
      var that = this;
      this.$refs["form"].validate(valid => {
        if (valid) {
          this.changePassword(this.form);
        } else {
          return false;
        }
      });
    },
    async changePassword(params) {
      let { data: saltRes } = await API.common.getSalt({
        accountName: params.accountName
      });
      let _params = Object.assign({}, params, {
        oldkamamm: sha256(params.oldkamamm + saltRes.data),
        newkamamm: sha256(params.newkamamm + saltRes.data)
      });
      let { data: res } = await API.common.changePassword(_params);
      checkError(res, res => {
        this.$message({
          type: "success",
          message: Vue.prototype.$t("set-success")
        });
        this.setToken("");
        this.setLogin(false);
        this.setMenuList(["projectList"]);
        this.setUserName("");
        this.$router.push({
          path: "/"
        });
      });
    },
    updatePassword() {
      this.form = {
        accountName: this.userName,
        oldkamamm: "",
        newkamamm: ""
      };
      this.centerDialogVisible = true;
    },
    link(sys) {
      if (sys == "module") {
        this.$router.push({ path: sys + "/-1" });
      } else {
        let reg = /^kfs$/i;
        if (reg.test(sys)) {
          let [defaultActive] = store.getters["common/list"][sys];
          this.$router.push({ name: defaultActive.path, params: { id: sys } });
        } else {
          this.$router.push({ name: sys, params: { id: sys } });
        }
      }
    },
    async updateUserLanguage(params) {
      let { data: res } = await API.common.updateUserLanguage(params);
      return res;
    },
    async sign(params) {
      let { data: res } = await API.common.sign(params);
      return res;
    },
    changeLang() {
      const h = this.$createElement;
      let langText;
      if (this.lang == "zh_CN") {
        langText = Vue.prototype.$t("lang-es");
      } else {
        langText = Vue.prototype.$t("lang-zh");
      }
      this.$msgbox({
        title: Vue.prototype.$t("setlang"),
        message: h("p", null, [
          h("span", null, Vue.prototype.$t("confirm-lang")),
          h("i", { style: "color: teal" }, langText)
        ]),
        showCancelButton: true,
        confirmButtonText: Vue.prototype.$t("sure"),
        cancelButtonText: Vue.prototype.$t("cancel"),
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            instance.confirmButtonLoading = true;
            instance.confirmButtonText = Vue.prototype.$t("loading");
            this.updateUserLanguage({
              accountName: this.userName,
              language: this.lang == "zh_CN" ? "en_us" : "zh_cn"
            }).then(res => {
              instance.confirmButtonLoading = false;
              checkError(res, res => {
                this.setToken(res.data);
                this.setLang(this.lang == "zh_CN" ? "en_us" : "zh_cn");
                window.location.reload();
                // this.$message({
                //   type: "success",
                //   message: "设置成功，重新登陆后生效"
                // });
                done();
              });
            });
          } else {
            done();
          }
        }
      });
    },
    signIn(e) {
      e.currentTarget.blur();
      this.$msgbox({
        title: Vue.prototype.$t("signout"),
        message: Vue.prototype.$t("confirm-signout"),
        showCancelButton: true,
        confirmButtonText: Vue.prototype.$t("sure"),
        cancelButtonText: Vue.prototype.$t("cancel"),
        beforeClose: (action, instance, done) => {
          if (action === "confirm") {
            instance.confirmButtonLoading = true;
            instance.confirmButtonText = Vue.prototype.$t("loading");
            this.sign({ accountName: this.userName }).then(res => {
              instance.confirmButtonLoading = false;
              checkError(res, res => {
                this.$message({
                  type: "success",
                  message: Vue.prototype.$t("signout-success")
                });
                this.setToken("");
                this.setLogin(false);
                this.setMenuList(["projectList"]);
                this.setBtnPermissionsArr([]);
                this.setUserName("");
                this.$router.push({
                  path: "/"
                });
                done();
              });
            });
          } else {
            done();
          }
        }
      });
    }
  }
};
</script>


<style lang="scss" scoped>
.projectList {
  height: calc(100% - 50px);
  padding: 50px;
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-start;
  align-items: flex-start;
  background: rgba(0, 0, 0, 0.3);
}
.el-dropdown-link:hover {
  cursor: pointer;
}
.project {
  opacity: 0.8;
  color: #fff;
  height: 150px;
  width: 250px;
  margin: 20px;
  line-height: 18px;
  text-align: center;
  border-radius: 10px;
  background: #fff;
  font-weight: bold;
  word-wrap: wrap;
  font-size: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 0.3s;
}

.project:hover {
  transform: translateY(-10px);
  opacity: 1;
}

.head-bar {
  height: 50px;
  background: rgba(0, 0, 0, 0.3);
}

.head-bar img {
  margin: 5px 10px;
  float: left;
}

.head-bar span {
  margin: 7px 10px;
  font-size: 30px;
  font-weight: bold;
  color: #fff;
  /* line-height: 50px; */
  float: left;
}

.container {
  width: 100%;
  height: 100%;
  background: url("../../assets/img/list.jpg") center no-repeat;
  background-size: cover;
  padding: 0;
}
</style>